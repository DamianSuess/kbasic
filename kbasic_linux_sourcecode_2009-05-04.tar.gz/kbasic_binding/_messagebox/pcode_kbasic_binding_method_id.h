static const int pcode___messagebox___messagebox = pcode___messagebox * SPACE;
static const int pcode___messagebox__METHOD_Show = pcode___messagebox___messagebox + 1;
static const int pcode___messagebox__METHOD_Critical = pcode___messagebox__METHOD_Show + 1;
static const int pcode___messagebox__METHOD_Information = pcode___messagebox__METHOD_Critical + 1;
static const int pcode___messagebox__METHOD_Question = pcode___messagebox__METHOD_Information + 1;
static const int pcode___messagebox__METHOD_Warning = pcode___messagebox__METHOD_Question + 1;
