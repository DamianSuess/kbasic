case pcode___color___color:{ getParam(v, m, n); pp = new kb_color(); myStack->pushParameter(pcode___color, pp); ((kb_color *) pp)->setInterpreter(this); break; }
                           /*
case pcode___color__METHOD_SetRGBA:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); q->METHOD_SetColor(v[0]->tot_integer(), v[1]->tot_integer(), v[2]->tot_integer(), v[3]->tot_integer()); break; }
case pcode___color__METHOD_RGBA:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); interpreter_parameter *p = new interpreter_parameter( q->METHOD_RGBA()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___color__SETPROPERTY_R:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); q->SETPROPERTY_R(v[0]->tot_integer()); break; }
case pcode___color__GETPROPERTY_R:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); interpreter_parameter *p = new interpreter_parameter( q->GETPROPERTY_R()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___color__SETPROPERTY_G:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); q->SETPROPERTY_G(v[0]->tot_integer()); break; }
case pcode___color__GETPROPERTY_G:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); interpreter_parameter *p = new interpreter_parameter( q->GETPROPERTY_G()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___color__SETPROPERTY_B:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); q->SETPROPERTY_B(v[0]->tot_integer()); break; }
case pcode___color__GETPROPERTY_B:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); interpreter_parameter *p = new interpreter_parameter( q->GETPROPERTY_B()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___color__SETPROPERTY_A:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); q->SETPROPERTY_A(v[0]->tot_integer()); break; }
case pcode___color__GETPROPERTY_A:{ getParam(v, m, n); identifier = popStack(); kb_color *q = (kb_color *) identifier->to_color(); interpreter_parameter *p = new interpreter_parameter( q->GETPROPERTY_A()); if (bReturn) pushStack(p); else delete p; break; }

                   */               