
new_class(pcode___color, 0, 0); 

/*
new_method(true, pcode___color, pcode___color___color, pcode___color);
	 new_param("R", pcode__t_integer, false);
	 new_param("G", pcode__t_integer, false);
	 new_param("B", pcode__t_integer, false);
	 new_param("A", pcode__t_integer, false);
new_method(true, pcode___color, pcode___color__METHOD_SetRGBA, pcode__VOID);
//new_method(true, pcode___color, pcode___color__METHOD_RGBA, pcode__t_long);
	 new_param("k", pcode__t_integer, false);
new_property_set(pcode___color, pcode___color__SETPROPERTY_R, pcode__VOID);
new_property_get(pcode___color, pcode___color__GETPROPERTY_R, pcode__t_integer);
	 new_param("k", pcode__t_integer, false);
new_property_set(pcode___color, pcode___color__SETPROPERTY_G, pcode__VOID);
new_property_get(pcode___color, pcode___color__GETPROPERTY_G, pcode__t_integer);
	 new_param("k", pcode__t_integer, false);
new_property_set(pcode___color, pcode___color__SETPROPERTY_B, pcode__VOID);
new_property_get(pcode___color, pcode___color__GETPROPERTY_B, pcode__t_integer);
	 new_param("k", pcode__t_integer, false);
new_property_set(pcode___color, pcode___color__SETPROPERTY_A, pcode__VOID);
new_property_get(pcode___color, pcode___color__GETPROPERTY_A, pcode__t_integer);
*/



new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_White, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Black, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Red, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_DarkRed, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Green, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Blue, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_DarkBlue, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Cyan, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_DarkCyan, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Magenta, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_DarkMagenta, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Yellow, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_DarkYellow, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Gray, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_DarkGray, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_LightGray, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Color0, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Color1, pcode___color);
new_staticproperty_get(pcode___color, pcode___color__GETPROPERTY_Transparent, pcode___color);