case pcode___databasedialog___databasedialog: return "DatabaseDialog";
  
case pcode___databasedialog__METHOD_GetDatabase: return "GetDatabase";
case pcode___databasedialog__METHOD_GetDatabase1: return "GetDatabase1";
case pcode___databasedialog__METHOD_Driver: return "Driver";
case pcode___databasedialog__METHOD_Host: return "Host";
case pcode___databasedialog__METHOD_Port: return "Port";
case pcode___databasedialog__METHOD_Name: return "Name";
case pcode___databasedialog__METHOD_User: return "User";
case pcode___databasedialog__METHOD_Password: return "Password";
case pcode___databasedialog__METHOD_Options: return "Options";
