static const int pcode___databasedialog___databasedialog = pcode___databasedialog * SPACE;

static const int pcode___databasedialog__METHOD_GetDatabase = pcode___databasedialog___databasedialog + 1;
static const int pcode___databasedialog__METHOD_GetDatabase1 = pcode___databasedialog__METHOD_GetDatabase + 1;
static const int pcode___databasedialog__METHOD_Driver = pcode___databasedialog__METHOD_GetDatabase1 + 1;
static const int pcode___databasedialog__METHOD_Host = pcode___databasedialog__METHOD_Driver + 1;
static const int pcode___databasedialog__METHOD_Port = pcode___databasedialog__METHOD_Host + 1;
static const int pcode___databasedialog__METHOD_Name = pcode___databasedialog__METHOD_Port + 1;
static const int pcode___databasedialog__METHOD_User = pcode___databasedialog__METHOD_Name + 1;
static const int pcode___databasedialog__METHOD_Password = pcode___databasedialog__METHOD_User + 1;
static const int pcode___databasedialog__METHOD_Options = pcode___databasedialog__METHOD_Password + 1;
