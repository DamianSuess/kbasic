
new_class(pcode___databasedialog, 0, 0); 


new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_GetDatabase, pcode__BOOLEAN);

    new_param("Driver", pcode__QSTRING, false);
    new_param("Host", pcode__QSTRING, false);
    new_param("Port", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
    new_param("User", pcode__QSTRING, false);
    new_param("Password", pcode__QSTRING, false);
    new_param("Options", pcode__QSTRING, false);
new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_GetDatabase1, pcode__BOOLEAN);

new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_Driver, pcode__QSTRING);
new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_Host, pcode__QSTRING);
new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_Port, pcode__QSTRING);
new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_Name, pcode__QSTRING);
new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_User, pcode__QSTRING);
new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_Password, pcode__QSTRING);
new_staticmethod(true, pcode___databasedialog, pcode___databasedialog__METHOD_Options, pcode__QSTRING);
