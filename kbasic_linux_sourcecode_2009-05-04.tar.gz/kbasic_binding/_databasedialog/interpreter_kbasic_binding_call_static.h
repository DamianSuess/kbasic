
case pcode___databasedialog__METHOD_GetDatabase:{ p = new interpreter_parameter(_databasedialog::METHOD_GetDatabase()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_GetDatabase1:{ p = new interpreter_parameter(_databasedialog::METHOD_GetDatabase(v[0]->toQString(), v[1]->toQString(), v[2]->toQString(), v[3]->toQString(), v[4]->toQString(), v[5]->toQString(), v[6]->toQString())); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_Driver:{ p = new interpreter_parameter(_databasedialog::METHOD_Driver()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_Host:{ p = new interpreter_parameter(_databasedialog::METHOD_Host()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_Port:{ p = new interpreter_parameter(_databasedialog::METHOD_Port()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_Name:{ p = new interpreter_parameter(_databasedialog::METHOD_Name()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_User:{ p = new interpreter_parameter(_databasedialog::METHOD_User()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_Password:{ p = new interpreter_parameter(_databasedialog::METHOD_Password()); if (bReturn) pushStack(p); else delete p; break; }
case pcode___databasedialog__METHOD_Options:{ p = new interpreter_parameter(_databasedialog::METHOD_Options()); if (bReturn) pushStack(p); else delete p; break; }
