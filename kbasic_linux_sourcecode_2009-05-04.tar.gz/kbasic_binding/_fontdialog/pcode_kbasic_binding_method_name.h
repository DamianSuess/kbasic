case pcode___fontdialog___fontdialog: return "FontDialog";
  
case pcode___fontdialog__METHOD_GetFont: return "GetFont";
case pcode___fontdialog__METHOD_GetFont1: return "GetFont1";


case pcode___fontdialog__METHOD_Name: return "NAME";
case pcode___fontdialog__METHOD_Size: return "Size";
case pcode___fontdialog__METHOD_Italic: return "Italic";
case pcode___fontdialog__METHOD_Bold: return "Bold";
case pcode___fontdialog__METHOD_Underline: return "Underline";

  /*
case pcode___fontdialog__METHOD_CustomCount: return "CustomCount";
case pcode___fontdialog__METHOD_SetCustomfont: return "SetCustomfont";
case pcode___fontdialog__METHOD_SetStandardfont: return "SetStandardfont";
*/