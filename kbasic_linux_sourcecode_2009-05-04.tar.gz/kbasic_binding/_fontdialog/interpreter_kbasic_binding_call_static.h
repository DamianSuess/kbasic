
case pcode___fontdialog__METHOD_GetFont:{ p = new interpreter_parameter(_fontdialog::METHOD_GetFont()); if (bReturn) pushStack(p); else delete p; break; }


case pcode___fontdialog__METHOD_GetFont1:{ p = new interpreter_parameter(_fontdialog::METHOD_GetFont1(v[0]->toQString(), v[1]->tot_integer(), v[2]->tot_boolean(), v[3]->tot_boolean(), v[4]->tot_boolean()));if (bReturn) pushStack(p); else delete p; break; }

case pcode___fontdialog__METHOD_Name:{ p = new interpreter_parameter(_fontdialog::METHOD_Name());if (bReturn) pushStack(p); else delete p; break; }
case pcode___fontdialog__METHOD_Size:{ p = new interpreter_parameter(_fontdialog::METHOD_Size());if (bReturn) pushStack(p); else delete p; break; }
case pcode___fontdialog__METHOD_Italic:{ p = new interpreter_parameter(_fontdialog::METHOD_Italic());if (bReturn) pushStack(p); else delete p; break; }
case pcode___fontdialog__METHOD_Bold:{ p = new interpreter_parameter(_fontdialog::METHOD_Bold());if (bReturn) pushStack(p); else delete p; break; }
case pcode___fontdialog__METHOD_Underline:{ p = new interpreter_parameter(_fontdialog::METHOD_Underline());if (bReturn) pushStack(p); else delete p; break; }

