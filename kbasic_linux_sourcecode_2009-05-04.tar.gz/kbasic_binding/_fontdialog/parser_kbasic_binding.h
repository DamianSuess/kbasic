
new_class(pcode___fontdialog, 0, 0); 


new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_GetFont, pcode__BOOLEAN);


    new_param("Name", pcode__QString, false);
    new_param("Size", pcode__INTEGER, false);
    new_param("Italic", pcode__BOOLEAN, false);
    new_param("Bold", pcode__BOOLEAN, false);
    new_param("Underline", pcode__BOOLEAN, false);
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_GetFont1, pcode__BOOLEAN);

new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_Name, pcode__QString);
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_Size, pcode__INTEGER);
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_Italic, pcode__BOOLEAN);
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_Bold, pcode__BOOLEAN);
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_Underline, pcode__BOOLEAN);

/*
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_CustomCount, pcode__INTEGER);

    new_param("Number", pcode__INTEGER, false);
    new_param("font", pcode__QString, false);
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_SetCustomfont, pcode__VOID);

    new_param("Number", pcode__INTEGER, false);
    new_param("font", pcode__QString, false);
new_staticmethod(true, pcode___fontdialog, pcode___fontdialog__METHOD_SetStandardfont, pcode__VOID);

*/