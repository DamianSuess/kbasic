static const int pcode___fontdialog___fontdialog = pcode___fontdialog * SPACE;
static const int pcode___fontdialog__METHOD_GetFont = pcode___fontdialog___fontdialog + 1;
static const int pcode___fontdialog__METHOD_GetFont1 = pcode___fontdialog__METHOD_GetFont + 1;
//static const int pcode___fontdialog__METHOD_Getfont2 = pcode___fontdialog__METHOD_Getfont1 + 1;

static const int pcode___fontdialog__METHOD_Name = pcode___fontdialog__METHOD_GetFont1 + 1;
static const int pcode___fontdialog__METHOD_Size = pcode___fontdialog__METHOD_Name + 1;
static const int pcode___fontdialog__METHOD_Italic = pcode___fontdialog__METHOD_Size + 1;
static const int pcode___fontdialog__METHOD_Bold = pcode___fontdialog__METHOD_Italic + 1;
static const int pcode___fontdialog__METHOD_Underline = pcode___fontdialog__METHOD_Bold + 1;



/*
static const int pcode___fontdialog__METHOD_CustomCount = pcode___fontdialog__METHOD_Getfont1 + 1;
static const int pcode___fontdialog__METHOD_SetCustomfont = pcode___fontdialog__METHOD_CustomCount + 1;
static const int pcode___fontdialog__METHOD_SetStandardfont = pcode___fontdialog__METHOD_SetCustomfont + 1;
*/