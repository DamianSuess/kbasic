case pcode___savedialog___savedialog: return "SaveDialog";
case pcode___savedialog__METHOD_GetFile: return "GetFile";
case pcode___savedialog__METHOD_GetFile1: return "GetFile1";
case pcode___savedialog__METHOD_GetDirectory: return "GetDirectory";
case pcode___savedialog__METHOD_GetDirectory1: return "GetDirectory1";
case pcode___savedialog__METHOD_SetMode: return "SetMode";
case pcode___savedialog__METHOD_SetOption: return "SetOption";
  