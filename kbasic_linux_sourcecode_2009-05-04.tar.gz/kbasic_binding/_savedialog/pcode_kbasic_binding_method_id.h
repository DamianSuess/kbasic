static const int pcode___savedialog___savedialog = pcode___savedialog * SPACE;
static const int pcode___savedialog__METHOD_GetFile = pcode___savedialog___savedialog + 1;
static const int pcode___savedialog__METHOD_GetFile1 = pcode___savedialog__METHOD_GetFile + 1;
static const int pcode___savedialog__METHOD_GetDirectory = pcode___savedialog__METHOD_GetFile1 + 1;
static const int pcode___savedialog__METHOD_GetDirectory1 = pcode___savedialog__METHOD_GetDirectory + 1;
static const int pcode___savedialog__METHOD_SetMode = pcode___savedialog__METHOD_GetDirectory1 + 1;
static const int pcode___savedialog__METHOD_SetOption = pcode___savedialog__METHOD_SetMode + 1;
