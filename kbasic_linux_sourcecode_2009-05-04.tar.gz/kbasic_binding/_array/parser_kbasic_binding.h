
new_class(pcode___array, 0, 0); 

new_method(true, pcode___array, pcode___array___array, pcode___array);

/*
	 new_param("Key", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Append, pcode__VOID);
*/

new_method(true, pcode___array, pcode___array__GET, pcode__QString);
new_method(true, pcode___array, pcode___array__SET, pcode__VOID);

/*
new_method(true, pcode___array, pcode___array__FOR, pcode__POINTER);
new_method(true, pcode___array, pcode___array__EACH, pcode__POINTER);

*/
/*
new_method(true, pcode___array, pcode___array__METHOD_Len, pcode__INTEGER);
	 new_param("Key", pcode__QString, false);
	 new_param("Value", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Append, pcode__VOID);
	 new_param("Key", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Get, pcode__QString);

	 new_param("Key", pcode__QString, false);
	 new_param("Value", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Set, pcode__VOID);

	 new_param("Key", pcode__QString, false);
	 new_param("Value", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Insert, pcode__VOID);

	 new_param("Key", pcode__QString, false);
	 new_param("Value", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Replace, pcode__VOID);

	 new_param("Key", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Remove, pcode__VOID);

new_method(true, pcode___array, pcode___array__METHOD_RemoveAll, pcode__VOID);

new_method(true, pcode___array, pcode___array__FOR, pcode__POINTER);
new_method(true, pcode___array, pcode___array__EACH, pcode__POINTER);

new_method(true, pcode___array, pcode___array__GET, pcode__QString);

	 new_param("Key", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_method(true, pcode___array, pcode___array__SET, pcode__VOID);

	 new_param("Key", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_Contains, pcode__VOID);

new_method(true, pcode___array, pcode___array__METHOD_Keys, pcode___strings);
new_method(true, pcode___array, pcode___array__METHOD_Values, pcode___strings);

new_method(true, pcode___array, pcode___array__METHOD_Key, pcode__QString);
new_method(true, pcode___array, pcode___array__METHOD_Value, pcode__QString);

*/
/*
new_method(true, pcode___array, pcode___array__METHOD_ReadBinary, pcode__QString);

	 new_param("Binary", pcode__QString, false);
new_method(true, pcode___array, pcode___array__METHOD_WriteBinary, pcode__VOID);
*/
