static const int pcode___array___array = pcode___array * SPACE;
static const int pcode___array__METHOD_Append = pcode___array___array + 1;
static const int pcode___array__GET = pcode___array__METHOD_Append + 1;
static const int pcode___array__SET = pcode___array__GET + 1;
static const int pcode___array__FOR = pcode___array__SET + 1;
static const int pcode___array__EACH = pcode___array__FOR + 1;

/*
static const int pcode___array__METHOD_Len = pcode___array___array + 1;
static const int pcode___array__METHOD_Get = pcode___array__METHOD_Append + 1;
static const int pcode___array__METHOD_Set = pcode___array__METHOD_Get + 1;
static const int pcode___array__GET = pcode___array__EACH + 1;
static const int pcode___array__SET = pcode___array__GET + 1;
static const int pcode___array__METHOD_RemoveAll = pcode___array__SET + 1;
static const int pcode___array__METHOD_Remove = pcode___array__METHOD_RemoveAll + 1;
static const int pcode___array__METHOD_Insert = pcode___array__METHOD_Remove + 1;

static const int pcode___array__METHOD_Contains = pcode___array__METHOD_Insert + 1;
static const int pcode___array__METHOD_ReadBinary = pcode___array__METHOD_Contains + 1;
static const int pcode___array__METHOD_WriteBinary = pcode___array__METHOD_ReadBinary + 1;
static const int pcode___array__METHOD_Keys = pcode___array__METHOD_WriteBinary + 1;
static const int pcode___array__METHOD_Values = pcode___array__METHOD_Keys + 1;
static const int pcode___array__METHOD_Replace = pcode___array__METHOD_Values + 1;
static const int pcode___array__METHOD_Key = pcode___array__METHOD_Replace + 1;
static const int pcode___array__METHOD_Value = pcode___array__METHOD_Key + 1;

*/