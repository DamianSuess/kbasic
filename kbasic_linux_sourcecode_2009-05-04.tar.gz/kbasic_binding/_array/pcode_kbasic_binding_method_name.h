case pcode___array___array: return "ARRAY";
case pcode___array__METHOD_Append: return "Append";
case pcode___array__GET: return "GET";
case pcode___array__SET: return "SET";
case pcode___array__FOR: return "FOR";
case pcode___array__EACH: return "EACH";

  /*
case pcode___array__METHOD_Len: return "Length";
case pcode___array__METHOD_Get: return "String";
case pcode___array__METHOD_Set: return "SetString";
case pcode___array__METHOD_RemoveAll: return "RemoveAll";
case pcode___array__METHOD_Remove: return "Remove";
case pcode___array__METHOD_Insert: return "Insert";

case pcode___array__METHOD_Contains: return "Contains";
case pcode___array__METHOD_ReadBinary: return "ReadBinary";
case pcode___array__METHOD_WriteBinary: return "WriteBinary";
case pcode___array__METHOD_Keys: return "Keys";
case pcode___array__METHOD_Values: return "Values";
case pcode___array__METHOD_Replace: return "Replace";
case pcode___array__METHOD_Key: return "Key";
case pcode___array__METHOD_Value: return "Value";
*/