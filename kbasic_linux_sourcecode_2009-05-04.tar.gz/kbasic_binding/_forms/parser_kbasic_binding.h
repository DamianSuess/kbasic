
new_class(pcode___forms, 0, 0); 

/*
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_ShowFullScreen, pcode__VOID);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_ShowMaximized, pcode__VOID);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_ShowMinimized, pcode__VOID);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_ShowNormal, pcode__VOID);*/
	 new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_Form, pcode___form);
	 new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_OpenForm, pcode__VOID);
	 new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_CloseForm, pcode__VOID);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FocusForm, pcode__QString);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FirstForm, pcode__QString);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_NextForm, pcode__QString);
	 new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_SetFocusForm, pcode__VOID);
	 new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_IsOpen, pcode__t_boolean);

   new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FormShowFullScreen, pcode__VOID);
   new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FormShowMaximized, pcode__VOID);
   new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FormShowMinimized, pcode__VOID);
   new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FormShowNormal, pcode__VOID);
   new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FormShow, pcode__VOID);
   new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___forms, pcode___forms__METHOD_FormHide, pcode__VOID);
