case pcode___forms___forms: return "Forms";
/*
case pcode___forms__METHOD_ShowFullScreen: return "ShowFullScreen";
case pcode___forms__METHOD_ShowMaximized: return "ShowMaximized";
case pcode___forms__METHOD_ShowMinimized: return "ShowMinimized";
case pcode___forms__METHOD_ShowNormal: return "ShowNormal";
*/
case pcode___forms__METHOD_Form: return "Form";
case pcode___forms__METHOD_OpenForm: return "Open";
case pcode___forms__METHOD_CloseForm: return "Close";
case pcode___forms__METHOD_FocusForm: return "Focus";
case pcode___forms__METHOD_FirstForm: return "First";
case pcode___forms__METHOD_NextForm: return "Next";
case pcode___forms__METHOD_SetFocusForm: return "SetFocus";
case pcode___forms__METHOD_IsOpen: return "IsOpen";

case pcode___forms__METHOD_FormShowFullScreen: return "ShowFullScreen";
case pcode___forms__METHOD_FormShowMaximized: return "ShowMaximized";
case pcode___forms__METHOD_FormShowMinimized: return "ShowMinimized";
case pcode___forms__METHOD_FormShowNormal: return "ShowNormal";
case pcode___forms__METHOD_FormShow: return "Show";
case pcode___forms__METHOD_FormHide: return "Hide";

      