static const int pcode___forms___forms = pcode___forms * SPACE;
/*
static const int pcode___forms__METHOD_ShowFullScreen = pcode___forms___forms + 1;
static const int pcode___forms__METHOD_ShowMaximized = pcode___forms__METHOD_ShowFullScreen + 1;
static const int pcode___forms__METHOD_ShowMinimized = pcode___forms__METHOD_ShowMaximized + 1;
static const int pcode___forms__METHOD_ShowNormal = pcode___forms__METHOD_ShowMinimized + 1;*/
static const int pcode___forms__METHOD_Form = pcode___forms___forms + 1;
static const int pcode___forms__METHOD_OpenForm = pcode___forms__METHOD_Form + 1;
static const int pcode___forms__METHOD_CloseForm = pcode___forms__METHOD_OpenForm + 1;
static const int pcode___forms__METHOD_FocusForm = pcode___forms__METHOD_CloseForm + 1;
static const int pcode___forms__METHOD_FirstForm = pcode___forms__METHOD_FocusForm + 1;
static const int pcode___forms__METHOD_NextForm = pcode___forms__METHOD_FirstForm + 1;

static const int pcode___forms__METHOD_SetFocusForm = pcode___forms__METHOD_NextForm + 1;
static const int pcode___forms__METHOD_IsOpen = pcode___forms__METHOD_SetFocusForm + 1;

static const int pcode___forms__METHOD_FormShowFullScreen = pcode___forms__METHOD_IsOpen + 1;
static const int pcode___forms__METHOD_FormShowMaximized = pcode___forms__METHOD_FormShowFullScreen + 1;
static const int pcode___forms__METHOD_FormShowMinimized = pcode___forms__METHOD_FormShowMaximized + 1;
static const int pcode___forms__METHOD_FormShowNormal = pcode___forms__METHOD_FormShowMinimized + 1;
static const int pcode___forms__METHOD_FormShow = pcode___forms__METHOD_FormShowNormal + 1;
static const int pcode___forms__METHOD_FormHide = pcode___forms__METHOD_FormShow + 1;


