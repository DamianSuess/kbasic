case pcode___footer___footer:{ getParam(v, m, n); pp = new kb_footer(v[0]->to_form()); myStack->pushParameter(pcode___footer, pp); ((kb_footer *) pp)->setInterpreter(this); break; }
