static const int pcode___footer___footer = pcode___footer * SPACE;

