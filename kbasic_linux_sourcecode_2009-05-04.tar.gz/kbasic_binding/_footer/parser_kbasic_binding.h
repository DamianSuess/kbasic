
new_class(pcode___footer, pcode___control, 0); 

	 new_param("f", pcode___form, false);
new_method(true, pcode___footer, pcode___footer___footer, pcode___footer);