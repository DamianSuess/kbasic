case pcode___actions___actions: return "Actions";

case pcode___actions__METHOD_SetEnabled: return "SetEnabled";
case pcode___actions__METHOD_IsEnabled: return "IsEnabled";

case pcode___actions__METHOD_SetVisible: return "SetVisible";
case pcode___actions__METHOD_IsVisible: return "IsVisible";

case pcode___actions__METHOD_SetChecked: return "SetChecked";
case pcode___actions__METHOD_IsChecked: return "IsChecked";

case pcode___actions__METHOD_SetStatusTip: return "SetStatusTip";
case pcode___actions__METHOD_StatusTip: return "StatusTip";

case pcode___actions__METHOD_SetToolTip: return "SetToolTip";
case pcode___actions__METHOD_ToolTip: return "ToolTip";

case pcode___actions__METHOD_SetWhatsThis: return "SetWhatsThis";
case pcode___actions__METHOD_WhatsThis: return "WhatsThis";

case pcode___actions__METHOD_SetIcon: return "SetIcon";
case pcode___actions__METHOD_Icon: return "Icon";

case pcode___actions__METHOD_SetTag: return "SetTag";
case pcode___actions__METHOD_Tag: return "Tag";

case pcode___actions__METHOD_SetCaption: return "SetCaption";
case pcode___actions__METHOD_Caption: return "Caption";

case pcode___actions__METHOD_SetText: return "SetText";
case pcode___actions__METHOD_Text: return "Text";

case pcode___actions__METHOD_SetSoundOnEvent: return "SetSoundOnEvent";
case pcode___actions__METHOD_SoundOnEvent: return "SoundOnEvent";

case pcode___actions__METHOD_SetGroup: return "SetGroup";
case pcode___actions__METHOD_Group: return "Group";

case pcode___actions__METHOD_SetKey: return "SetKey";
case pcode___actions__METHOD_Key: return "Key";

