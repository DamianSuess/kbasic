
new_class(pcode___actions, 0, 0); 


   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__BOOLEAN, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetEnabled, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_IsEnabled, pcode__BOOLEAN);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__BOOLEAN, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetVisible, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_IsVisible, pcode__BOOLEAN);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__BOOLEAN, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetChecked, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_IsChecked, pcode__BOOLEAN);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetStatusTip, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_StatusTip, pcode__QString);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetToolTip, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_ToolTip, pcode__QString);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetWhatsThis, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_WhatsThis, pcode__QString);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetIcon, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_Icon, pcode__QString);
    
   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetTag, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_Tag, pcode__QString);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetCaption, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_Caption, pcode__QString);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetText, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_Text, pcode__QString);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetSoundOnEvent, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SoundOnEvent, pcode__QString);

   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetGroup, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_Group, pcode__QString);

    
   new_param("ActionId", pcode__QString, false);
   new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_SetKey, pcode__VOID);
   new_param("ActionId", pcode__QString, false);
new_staticmethod(true, pcode___actions, pcode___actions__METHOD_Key, pcode__QString);

    