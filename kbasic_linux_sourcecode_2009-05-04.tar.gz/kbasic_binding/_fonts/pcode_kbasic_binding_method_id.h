static const int pcode___fonts___fonts = pcode___fonts * SPACE;
static const int pcode___fonts__METHOD_Font = pcode___fonts___fonts + 1;
static const int pcode___fonts__METHOD_SetFont = pcode___fonts__METHOD_Font + 1;