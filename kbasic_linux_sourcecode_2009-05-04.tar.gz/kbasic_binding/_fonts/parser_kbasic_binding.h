
new_class(pcode___fonts, 0, 0); 

//new_method(true, pcode___fonts, pcode___fonts___fonts, pcode___fonts);

/*
	 new_param("Name", pcode__QString, false);
new_staticmethod(true, pcode___fonts, pcode___fonts__METHOD_Font, pcode___font);

*/
	 new_param("Name", pcode__QString, false);
	 new_param("fName", pcode__QString, false);
	 new_param("Size", pcode__t_integer, false);
	 new_param("Italic", pcode__t_boolean, false);
	 new_param("Bold", pcode__t_boolean, false);
	 new_param("Underline", pcode__t_boolean, false);
new_staticmethod(true, pcode___fonts, pcode___fonts__METHOD_SetFont, pcode__VOID);