case pcode___sounds___sounds: return "Sounds";
case pcode___sounds__METHOD_Load: return "Load";
case pcode___sounds__METHOD_SetSound: return "SetSound";
case pcode___sounds__METHOD_Play: return "Play";
