static const int pcode___sounds___sounds = pcode___sounds * SPACE;
static const int pcode___sounds__METHOD_Load = pcode___sounds___sounds + 1;
static const int pcode___sounds__METHOD_SetSound = pcode___sounds__METHOD_Load + 1;
static const int pcode___sounds__METHOD_Play = pcode___sounds__METHOD_SetSound + 1;

