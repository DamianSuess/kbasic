
static const int pcode___record___record = pcode___record * SPACE;

static const int pcode___record__METHOD_Open = pcode___record___record + 1;
static const int pcode___record__METHOD_Open1 = pcode___record__METHOD_Open + 1;
static const int pcode___record__METHOD_Open2 = pcode___record__METHOD_Open1 + 1;
static const int pcode___record__METHOD_Open3 = pcode___record__METHOD_Open2 + 1;
static const int pcode___record__METHOD_Open4 = pcode___record__METHOD_Open3 + 1;
static const int pcode___record__METHOD_Open5 = pcode___record__METHOD_Open4 + 1;
static const int pcode___record__METHOD_Close = pcode___record__METHOD_Open5 + 1;
static const int pcode___record__METHOD_Requery = pcode___record__METHOD_Close + 1;
static const int pcode___record__METHOD_First = pcode___record__METHOD_Requery + 1;
static const int pcode___record__METHOD_Next = pcode___record__METHOD_First + 1;
static const int pcode___record__METHOD_Previous = pcode___record__METHOD_Next + 1;
static const int pcode___record__METHOD_Last = pcode___record__METHOD_Previous + 1;
static const int pcode___record__METHOD_GoTo = pcode___record__METHOD_Last + 1;
static const int pcode___record__METHOD_Length = pcode___record__METHOD_GoTo + 1;
static const int pcode___record__METHOD_Position = pcode___record__METHOD_Length + 1;
static const int pcode___record__METHOD_AddNew = pcode___record__METHOD_Position + 1;
static const int pcode___record__METHOD_Insert = pcode___record__METHOD_AddNew + 1;
static const int pcode___record__METHOD_Update = pcode___record__METHOD_Insert + 1;
static const int pcode___record__METHOD_Delete = pcode___record__METHOD_Update + 1;
static const int pcode___record__METHOD_Clear = pcode___record__METHOD_Delete + 1;
static const int pcode___record__METHOD_Set = pcode___record__METHOD_Clear + 1;
static const int pcode___record__METHOD_Get = pcode___record__METHOD_Set + 1;
static const int pcode___record__METHOD_Fields = pcode___record__METHOD_Get + 1;
static const int pcode___record__METHOD_PrimaryKeyName = pcode___record__METHOD_Fields + 1;
static const int pcode___record__METHOD_PrimaryKey = pcode___record__METHOD_PrimaryKeyName + 1;
