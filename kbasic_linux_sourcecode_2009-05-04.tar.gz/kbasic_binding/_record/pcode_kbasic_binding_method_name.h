
case pcode___record___record: return "Records";

case pcode___record__METHOD_Open: return "Open";
case pcode___record__METHOD_Open1: return "Open1";
case pcode___record__METHOD_Open2: return "Open2";
case pcode___record__METHOD_Open3: return "Open3";
case pcode___record__METHOD_Open4: return "Open4";
case pcode___record__METHOD_Open5: return "Open5";
case pcode___record__METHOD_Close: return "Close";
case pcode___record__METHOD_Requery: return "Requery";
case pcode___record__METHOD_First: return "First";
case pcode___record__METHOD_Next: return "Next";
case pcode___record__METHOD_Previous: return "Previous";
case pcode___record__METHOD_Last: return "Last";
case pcode___record__METHOD_GoTo: return "GoTo";
case pcode___record__METHOD_Length: return "Length";
case pcode___record__METHOD_Position: return "Position";
case pcode___record__METHOD_AddNew: return "AddNew";
case pcode___record__METHOD_Insert: return "Insert";
case pcode___record__METHOD_Update: return "Update";
case pcode___record__METHOD_Delete: return "Delete";
case pcode___record__METHOD_Clear: return "ClearFields";
case pcode___record__METHOD_Set: return "SetField";
case pcode___record__METHOD_Get: return "Value";
case pcode___record__METHOD_Fields: return "FieldNames";
case pcode___record__METHOD_PrimaryKeyName: return "PrimaryKeyName";
case pcode___record__METHOD_PrimaryKey: return "PrimaryKey";
