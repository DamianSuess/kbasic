case pcode___menubaritem___menubaritem: return "MenuBarItem";

case pcode___menubaritem__SETPROPERTY_ActionId: return "SETPROPERTY_ActionId";
case pcode___menubaritem__GETPROPERTY_ActionId: return "GETPROPERTY_ActionId";

case pcode___menubaritem__SETPROPERTY_Checkable: return "SETPROPERTY_Checkable";
case pcode___menubaritem__GETPROPERTY_Checkable: return "GETPROPERTY_Checkable";
case pcode___menubaritem__SETPROPERTY_Visible: return "SETPROPERTY_Visible";
case pcode___menubaritem__GETPROPERTY_Visible: return "GETPROPERTY_Visible";
case pcode___menubaritem__SETPROPERTY_MenuBarRole: return "SETPROPERTY_MenuBarRole";
case pcode___menubaritem__GETPROPERTY_MenuBarRole: return "GETPROPERTY_MenuBarRole";
case pcode___menubaritem__SETPROPERTY_Data: return "SETPROPERTY_Data";
case pcode___menubaritem__GETPROPERTY_Data: return "GETPROPERTY_Data";

case pcode___menubaritem__SETPROPERTY_Name: return "SETPROPERTY_Name";
case pcode___menubaritem__GETPROPERTY_Name: return "GETPROPERTY_Name";
case pcode___menubaritem__SETPROPERTY_ControlType: return "SETPROPERTY_ControlType";
case pcode___menubaritem__GETPROPERTY_ControlType: return "GETPROPERTY_ControlType";
case pcode___menubaritem__SETPROPERTY_ParentControl: return "SETPROPERTY_ParentControl";
case pcode___menubaritem__GETPROPERTY_ParentControl: return "GETPROPERTY_ParentControl";

case pcode___menubaritem__SETPROPERTY_Caption: return "SETPROPERTY_Caption";
case pcode___menubaritem__GETPROPERTY_Caption: return "GETPROPERTY_Caption";
case pcode___menubaritem__SETPROPERTY_Text: return "SETPROPERTY_Text";
case pcode___menubaritem__GETPROPERTY_Text: return "GETPROPERTY_Text";

case pcode___menubaritem__SETPROPERTY_Separator: return "SETPROPERTY_Separator";
case pcode___menubaritem__GETPROPERTY_Separator: return "GETPROPERTY_Separator";
case pcode___menubaritem__SETPROPERTY_Tag: return "SETPROPERTY_Tag";
case pcode___menubaritem__GETPROPERTY_Tag: return "GETPROPERTY_Tag";
case pcode___menubaritem__SETPROPERTY_Group: return "SETPROPERTY_Group";
case pcode___menubaritem__GETPROPERTY_Group: return "GETPROPERTY_Group";
case pcode___menubaritem__SETPROPERTY_Value: return "SETPROPERTY_Value";
case pcode___menubaritem__GETPROPERTY_Value: return "GETPROPERTY_Value";
case pcode___menubaritem__SETPROPERTY_Enabled: return "SETPROPERTY_Enabled";
case pcode___menubaritem__GETPROPERTY_Enabled: return "GETPROPERTY_Enabled";
case pcode___menubaritem__SETPROPERTY_Checked: return "SETPROPERTY_Checked";
case pcode___menubaritem__GETPROPERTY_Checked: return "GETPROPERTY_Checked";
case pcode___menubaritem__SETPROPERTY_Icon: return "SETPROPERTY_Icon";
case pcode___menubaritem__GETPROPERTY_Icon: return "GETPROPERTY_Icon";
case pcode___menubaritem__SETPROPERTY_ParentIndex: return "SETPROPERTY_ParentIndex";
case pcode___menubaritem__GETPROPERTY_ParentIndex: return "GETPROPERTY_ParentIndex";
case pcode___menubaritem__SETPROPERTY_Key: return "SETPROPERTY_Key";
case pcode___menubaritem__GETPROPERTY_Key: return "GETPROPERTY_Key";
case pcode___menubaritem__SETPROPERTY_StatusTip: return "SETPROPERTY_StatusTip";
case pcode___menubaritem__GETPROPERTY_StatusTip: return "GETPROPERTY_StatusTip";
case pcode___menubaritem__SETPROPERTY_SoundOnEvent: return "SETPROPERTY_SoundOnEvent";
case pcode___menubaritem__GETPROPERTY_SoundOnEvent: return "GETPROPERTY_SoundOnEvent";
case pcode___menubaritem__EVENT_OnEvent: return "OnEvent";