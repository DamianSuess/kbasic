
new_class(pcode___menubaritem, 0, 0); 

	 new_param("f", pcode___form, false);
new_method(true, pcode___menubaritem, pcode___menubaritem___menubaritem, pcode___menubaritem);


	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_ActionId, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_ActionId, pcode__QString);

	 new_param("n", pcode__BOOLEAN, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Checkable, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Checkable, pcode__BOOLEAN);

	 new_param("n", pcode__BOOLEAN, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Visible, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Visible, pcode__BOOLEAN);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_MenuBarRole, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_MenuBarRole, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Data, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Data, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Name, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Name, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_ControlType, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_ControlType, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_ParentControl, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_ParentControl, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Caption, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Caption, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Text, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Text, pcode__QString);

	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Separator, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Separator, pcode__t_boolean);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Tag, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Tag, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Group, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Group, pcode__QString);
	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Enabled, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Enabled, pcode__t_boolean);

	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Checked, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Checked, pcode__t_boolean);

   new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Icon, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Icon, pcode__QString);
	 new_param("n", pcode__t_integer, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_ParentIndex, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_ParentIndex, pcode__t_integer);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_Key, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_Key, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_StatusTip, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_StatusTip, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___menubaritem, pcode___menubaritem__SETPROPERTY_SoundOnEvent, pcode__VOID);
new_property_get(pcode___menubaritem, pcode___menubaritem__GETPROPERTY_SoundOnEvent, pcode__QString);

new_method(true, pcode___menubaritem, pcode___menubaritem__EVENT_OnEvent, pcode__VOID, false, false, false, true);