static const int pcode___menubaritem___menubaritem = pcode___menubaritem * SPACE;

static const int pcode___menubaritem__SETPROPERTY_ActionId = pcode___menubaritem___menubaritem + 1;
static const int pcode___menubaritem__GETPROPERTY_ActionId = pcode___menubaritem__SETPROPERTY_ActionId + 1;

static const int pcode___menubaritem__SETPROPERTY_Checkable = pcode___menubaritem__GETPROPERTY_ActionId + 1;
static const int pcode___menubaritem__GETPROPERTY_Checkable = pcode___menubaritem__SETPROPERTY_Checkable + 1;
static const int pcode___menubaritem__SETPROPERTY_Visible = pcode___menubaritem__GETPROPERTY_Checkable + 1;
static const int pcode___menubaritem__GETPROPERTY_Visible = pcode___menubaritem__SETPROPERTY_Visible + 1;
static const int pcode___menubaritem__SETPROPERTY_MenuBarRole = pcode___menubaritem__GETPROPERTY_Visible + 1;
static const int pcode___menubaritem__GETPROPERTY_MenuBarRole = pcode___menubaritem__SETPROPERTY_MenuBarRole + 1;
static const int pcode___menubaritem__SETPROPERTY_Data = pcode___menubaritem__GETPROPERTY_MenuBarRole + 1;
static const int pcode___menubaritem__GETPROPERTY_Data = pcode___menubaritem__SETPROPERTY_Data + 1;

static const int pcode___menubaritem__SETPROPERTY_Name = pcode___menubaritem__GETPROPERTY_Data + 1;
static const int pcode___menubaritem__GETPROPERTY_Name = pcode___menubaritem__SETPROPERTY_Name + 1;
static const int pcode___menubaritem__SETPROPERTY_ControlType = pcode___menubaritem__GETPROPERTY_Name + 1;
static const int pcode___menubaritem__GETPROPERTY_ControlType = pcode___menubaritem__SETPROPERTY_ControlType + 1;
static const int pcode___menubaritem__SETPROPERTY_ParentControl = pcode___menubaritem__GETPROPERTY_ControlType + 1;
static const int pcode___menubaritem__GETPROPERTY_ParentControl = pcode___menubaritem__SETPROPERTY_ParentControl + 1;

static const int pcode___menubaritem__SETPROPERTY_Caption = pcode___menubaritem__GETPROPERTY_ParentControl + 1;
static const int pcode___menubaritem__GETPROPERTY_Caption = pcode___menubaritem__SETPROPERTY_Caption + 1;
static const int pcode___menubaritem__SETPROPERTY_Text = pcode___menubaritem__GETPROPERTY_Caption + 1;
static const int pcode___menubaritem__GETPROPERTY_Text = pcode___menubaritem__SETPROPERTY_Text + 1;

static const int pcode___menubaritem__SETPROPERTY_Separator = pcode___menubaritem__GETPROPERTY_Text + 1;
static const int pcode___menubaritem__GETPROPERTY_Separator = pcode___menubaritem__SETPROPERTY_Separator + 1;
static const int pcode___menubaritem__SETPROPERTY_Tag = pcode___menubaritem__GETPROPERTY_Separator + 1;
static const int pcode___menubaritem__GETPROPERTY_Tag = pcode___menubaritem__SETPROPERTY_Tag + 1;
static const int pcode___menubaritem__SETPROPERTY_Group = pcode___menubaritem__GETPROPERTY_Tag + 1;
static const int pcode___menubaritem__GETPROPERTY_Group = pcode___menubaritem__SETPROPERTY_Group + 1;
static const int pcode___menubaritem__SETPROPERTY_Value = pcode___menubaritem__GETPROPERTY_Group + 1;
static const int pcode___menubaritem__GETPROPERTY_Value = pcode___menubaritem__SETPROPERTY_Value + 1;
static const int pcode___menubaritem__SETPROPERTY_Enabled = pcode___menubaritem__GETPROPERTY_Value + 1;
static const int pcode___menubaritem__GETPROPERTY_Enabled = pcode___menubaritem__SETPROPERTY_Enabled + 1;
static const int pcode___menubaritem__SETPROPERTY_Checked = pcode___menubaritem__GETPROPERTY_Enabled + 1;
static const int pcode___menubaritem__GETPROPERTY_Checked = pcode___menubaritem__SETPROPERTY_Checked + 1;
static const int pcode___menubaritem__SETPROPERTY_Icon = pcode___menubaritem__GETPROPERTY_Checked + 1;
static const int pcode___menubaritem__GETPROPERTY_Icon = pcode___menubaritem__SETPROPERTY_Icon + 1;
static const int pcode___menubaritem__SETPROPERTY_ParentIndex = pcode___menubaritem__GETPROPERTY_Icon + 1;
static const int pcode___menubaritem__GETPROPERTY_ParentIndex = pcode___menubaritem__SETPROPERTY_ParentIndex + 1;
static const int pcode___menubaritem__SETPROPERTY_Key = pcode___menubaritem__GETPROPERTY_ParentIndex + 1;
static const int pcode___menubaritem__GETPROPERTY_Key = pcode___menubaritem__SETPROPERTY_Key + 1;
static const int pcode___menubaritem__SETPROPERTY_StatusTip = pcode___menubaritem__GETPROPERTY_Key + 1;
static const int pcode___menubaritem__GETPROPERTY_StatusTip = pcode___menubaritem__SETPROPERTY_StatusTip + 1;
static const int pcode___menubaritem__SETPROPERTY_SoundOnEvent = pcode___menubaritem__GETPROPERTY_StatusTip + 1;
static const int pcode___menubaritem__GETPROPERTY_SoundOnEvent = pcode___menubaritem__SETPROPERTY_SoundOnEvent + 1;
static const int pcode___menubaritem__EVENT_OnEvent = pcode___menubaritem__GETPROPERTY_SoundOnEvent + 1;