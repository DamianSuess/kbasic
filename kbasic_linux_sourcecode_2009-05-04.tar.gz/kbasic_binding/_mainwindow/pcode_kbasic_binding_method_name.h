case pcode___mainwindow___mainwindow: return "MainWindow";

case pcode___mainwindow__METHOD_SetVisible: return "SetVisible";
case pcode___mainwindow__METHOD_IsVisible: return "IsVisible";

case pcode___mainwindow__METHOD_SetViewMode: return "SetViewMode";
case pcode___mainwindow__METHOD_ViewMode: return "ViewMode";

case pcode___mainwindow__PROPERTYSET_X: return "SETPROPERTY_X";
case pcode___mainwindow__PROPERTYGET_X: return "GETPROPERTY_X";
case pcode___mainwindow__PROPERTYSET_Y: return "SETPROPERTY_Y";
case pcode___mainwindow__PROPERTYGET_Y: return "GETPROPERTY_Y";
case pcode___mainwindow__PROPERTYSET_Width: return "SETPROPERTY_Width";
case pcode___mainwindow__PROPERTYGET_Width: return "GETPROPERTY_Width";
case pcode___mainwindow__PROPERTYSET_Height: return "SETPROPERTY_Height";
case pcode___mainwindow__PROPERTYGET_Height: return "GETPROPERTY_Height";

case pcode___mainwindow__METHOD_Move: return "Move";
case pcode___mainwindow__METHOD_Resize: return "Resize";
case pcode___mainwindow__METHOD_Close: return "Close";
case pcode___mainwindow__METHOD_CloseAllWindows: return "CloseAllWindows";
case pcode___mainwindow__METHOD_IsScrollBarsEnabled: return "IsScrollBarsEnabled";

case pcode___mainwindow__METHOD_ShowFullScreen: return "ShowFullScreen";
case pcode___mainwindow__METHOD_ShowMaximized: return "ShowMaximized";
case pcode___mainwindow__METHOD_ShowMinimized: return "ShowMinimized";
case pcode___mainwindow__METHOD_ShowNormal: return "ShowNormal";

case pcode___mainwindow__METHOD_SetFocusNextForm: return "SetFocusNext";
case pcode___mainwindow__METHOD_SetFocusPreviousForm: return "SetFocusPrevious";
case pcode___mainwindow__METHOD_Cascade: return "Cascade";
case pcode___mainwindow__METHOD_CloseActiveForm: return "CloseActive";
case pcode___mainwindow__METHOD_CloseAllapplication: return "CloseAll";
case pcode___mainwindow__METHOD_Tile: return "Tile";
case pcode___mainwindow__METHOD_SetScrollBarsEnabled: return "SetScrollBarsEnabled";

case pcode___mainwindow__METHOD_SetCaption: return "SetCaption";
case pcode___mainwindow__METHOD_SetIcon: return "SetIcon";
