case pcode___colors___colors: return "Colors";
case pcode___colors__METHOD_Color: return "Color";
case pcode___colors__METHOD_SetRGBA: return "SetColor";