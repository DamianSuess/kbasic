
new_class(pcode___colors, 0, 0); 

//new_method(true, pcode___colors, pcode___colors___colors, pcode___colors);
/*
	 new_param("Name", pcode__QString, false);
new_staticmethod(true, pcode___colors, pcode___colors__METHOD_Color, pcode___color);

*/
	 new_param("Name", pcode__QString, false);
	 new_param("R", pcode__t_integer, false);
	 new_param("G", pcode__t_integer, false);
	 new_param("B", pcode__t_integer, false);
	 new_param("A", pcode__t_integer, false);
new_staticmethod(true, pcode___colors, pcode___colors__METHOD_SetRGBA, pcode__VOID);