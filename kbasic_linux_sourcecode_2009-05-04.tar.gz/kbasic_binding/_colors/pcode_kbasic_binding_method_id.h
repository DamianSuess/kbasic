static const int pcode___colors___colors = pcode___colors * SPACE;
static const int pcode___colors__METHOD_Color = pcode___colors___colors + 1;
static const int pcode___colors__METHOD_SetRGBA = pcode___colors__METHOD_Color + 1;