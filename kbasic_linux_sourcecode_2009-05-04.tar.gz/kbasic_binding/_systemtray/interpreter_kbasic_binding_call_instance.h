case pcode___systemtray___systemtray:{ getParam(v, m, n); pp = new kb_systemtray(); myStack->pushParameter(pcode___systemtray, pp); ((kb_systemtray *) pp)->setInterpreter(this); break; }
