case pcode___systemtray___systemtray: return "SystemTray";

case pcode___systemtray__METHOD_IsSystemTrayAvailable: return "IsSystemTrayAvailable";
case pcode___systemtray__METHOD_IsPrintSupported: return "IsPrintSupported";
  
case pcode___systemtray__METHOD_Print: return "Print";
case pcode___systemtray__METHOD_Print1: return "Print1";
case pcode___systemtray__METHOD_Print2: return "Print2";
case pcode___systemtray__METHOD_Print3: return "Print3";
case pcode___systemtray__METHOD_Show: return "Show";
case pcode___systemtray__METHOD_Hide: return "Hide";
case pcode___systemtray__METHOD_ToggleVisible: return "ToggleVisible";
case pcode___systemtray__PROPERTYSET_ContextMenu: return "SETPROPERTY_ContextMenu";
case pcode___systemtray__PROPERTYGET_ContextMenu: return "GETPROPERTY_ContextMenu";
case pcode___systemtray__PROPERTYSET_Icon: return "SETPROPERTY_Icon";
case pcode___systemtray__PROPERTYGET_Icon: return "GETPROPERTY_Icon";
case pcode___systemtray__PROPERTYSET_ToolTip: return "SETPROPERTY_ToolTip";
case pcode___systemtray__PROPERTYGET_ToolTip: return "GETPROPERTY_ToolTip";
case pcode___systemtray__PROPERTYSET_Visible: return "SETPROPERTY_Visible";
case pcode___systemtray__PROPERTYGET_Visible: return "GETPROPERTY_Visible";
case pcode___systemtray__PROPERTYGET_GlobalX: return "GETPROPERTY_GlobalX";
case pcode___systemtray__PROPERTYGET_GlobalY: return "GETPROPERTY_GlobalY";
case pcode___systemtray__PROPERTYGET_Width: return "GETPROPERTY_Width";
case pcode___systemtray__PROPERTYGET_Height: return "GETPROPERTY_Height";
