static const int pcode___systemtray___systemtray = pcode___systemtray * SPACE;

static const int pcode___systemtray__METHOD_IsSystemTrayAvailable = pcode___systemtray___systemtray + 1;
static const int pcode___systemtray__METHOD_IsPrintSupported = pcode___systemtray__METHOD_IsSystemTrayAvailable + 1;

static const int pcode___systemtray__METHOD_Print = pcode___systemtray__METHOD_IsPrintSupported + 1;
static const int pcode___systemtray__METHOD_Print1 = pcode___systemtray__METHOD_Print + 1;
static const int pcode___systemtray__METHOD_Print2 = pcode___systemtray__METHOD_Print1 + 1;
static const int pcode___systemtray__METHOD_Print3 = pcode___systemtray__METHOD_Print2 + 1;
static const int pcode___systemtray__METHOD_Show = pcode___systemtray__METHOD_Print3 + 1;
static const int pcode___systemtray__METHOD_Hide = pcode___systemtray__METHOD_Show + 1;
static const int pcode___systemtray__METHOD_ToggleVisible = pcode___systemtray__METHOD_Hide + 1;
static const int pcode___systemtray__PROPERTYSET_ContextMenu = pcode___systemtray__METHOD_ToggleVisible + 1;
static const int pcode___systemtray__PROPERTYGET_ContextMenu = pcode___systemtray__PROPERTYSET_ContextMenu + 1;
static const int pcode___systemtray__PROPERTYSET_Icon = pcode___systemtray__PROPERTYGET_ContextMenu + 1;
static const int pcode___systemtray__PROPERTYGET_Icon = pcode___systemtray__PROPERTYSET_Icon + 1;
static const int pcode___systemtray__PROPERTYSET_ToolTip = pcode___systemtray__PROPERTYGET_Icon + 1;
static const int pcode___systemtray__PROPERTYGET_ToolTip = pcode___systemtray__PROPERTYSET_ToolTip + 1;
static const int pcode___systemtray__PROPERTYSET_Visible = pcode___systemtray__PROPERTYGET_ToolTip + 1;
static const int pcode___systemtray__PROPERTYGET_Visible = pcode___systemtray__PROPERTYSET_Visible + 1;
//static const int pcode___systemtray__PROPERTYSET_GlobalX = pcode___systemtray__PROPERTYGET_Visible + 1;
static const int pcode___systemtray__PROPERTYGET_GlobalX = pcode___systemtray__PROPERTYGET_Visible + 1;
//static const int pcode___systemtray__PROPERTYSET_GlobalY = pcode___systemtray__PROPERTYGET_GlobalX + 1;
static const int pcode___systemtray__PROPERTYGET_GlobalY = pcode___systemtray__PROPERTYGET_GlobalX + 1;
//static const int pcode___systemtray__PROPERTYSET_Width = pcode___systemtray__PROPERTYGET_GlobalY + 1;
static const int pcode___systemtray__PROPERTYGET_Width = pcode___systemtray__PROPERTYGET_GlobalY + 1;
//static const int pcode___systemtray__PROPERTYSET_Height = pcode___systemtray__PROPERTYGET_Width + 1;
static const int pcode___systemtray__PROPERTYGET_Height = pcode___systemtray__PROPERTYGET_Width + 1;


