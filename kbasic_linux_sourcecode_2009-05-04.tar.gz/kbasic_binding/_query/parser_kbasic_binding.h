
new_class(pcode___query, 0, 0); 


    new_param("Database", pcode__QSTRING, false);
    new_param("QueryNameOrSql", pcode__QSTRING, false);
new_staticmethod(true, pcode___query, pcode___query__METHOD_Run, pcode__BOOLEAN);

    new_param("QueryNameOrSql", pcode__QSTRING, false);
new_staticmethod(true, pcode___query, pcode___query__METHOD_Run1, pcode__BOOLEAN);
