
new_class(pcode___opendialog, 0, 0); 

new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_GetFile, pcode__QString);

    new_param("Caption", pcode__QString, false);
    new_param("Directory", pcode__QString, false);
    new_param("Filter", pcode__QString, false);
new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_GetFile1, pcode__QString);

new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_GetFiles, pcode___strings);

    new_param("Caption", pcode__QString, false);
    new_param("Directory", pcode__QString, false);
    new_param("Filter", pcode__QString, false);
new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_GetFiles1, pcode___strings);

new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_GetDirectory, pcode__QString);

    new_param("Caption", pcode__QString, false);
    new_param("Directory", pcode__QString, false);
new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_GetDirectory1, pcode__QString);

/*
    new_param("Mode", pcode___strings, false);
new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_SetMode, pcode__VOID);

    new_param("Option", pcode___strings, false);
new_staticmethod(true, pcode___opendialog, pcode___opendialog__METHOD_SetOption, pcode__VOID);
*/