case pcode___opendialog___opendialog: return "SaveDialog";
case pcode___opendialog__METHOD_GetFile: return "GetFile";
case pcode___opendialog__METHOD_GetFile1: return "GetFile1";
case pcode___opendialog__METHOD_GetFiles: return "GetFiles";
case pcode___opendialog__METHOD_GetFiles1: return "GetFiles1";
case pcode___opendialog__METHOD_GetDirectory: return "GetDirectory";
case pcode___opendialog__METHOD_GetDirectory1: return "GetDirectory1";
case pcode___opendialog__METHOD_SetMode: return "SetMode";
case pcode___opendialog__METHOD_SetOption: return "SetOption";
  