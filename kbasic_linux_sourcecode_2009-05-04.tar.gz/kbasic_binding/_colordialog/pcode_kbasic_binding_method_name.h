case pcode___colordialog___colordialog: return "ColorDialog";
  
case pcode___colordialog__METHOD_GetColor: return "GetColor";
case pcode___colordialog__METHOD_GetColor1: return "GetColor1";
//case pcode___colordialog__METHOD_GetColor2: return "GetColor2";

case pcode___colordialog__METHOD_Red: return "Red";
case pcode___colordialog__METHOD_Green: return "Green";
case pcode___colordialog__METHOD_Blue: return "Blue";
case pcode___colordialog__METHOD_Alpha: return "Alpha";

  /*
case pcode___colordialog__METHOD_CustomCount: return "CustomCount";
case pcode___colordialog__METHOD_SetCustomColor: return "SetCustomColor";
case pcode___colordialog__METHOD_SetStandardColor: return "SetStandardColor";
*/