static const int pcode___colordialog___colordialog = pcode___colordialog * SPACE;
static const int pcode___colordialog__METHOD_GetColor = pcode___colordialog___colordialog + 1;
static const int pcode___colordialog__METHOD_GetColor1 = pcode___colordialog__METHOD_GetColor + 1;
//static const int pcode___colordialog__METHOD_GetColor2 = pcode___colordialog__METHOD_GetColor1 + 1;

static const int pcode___colordialog__METHOD_Red = pcode___colordialog__METHOD_GetColor1 + 1;
static const int pcode___colordialog__METHOD_Green = pcode___colordialog__METHOD_Red + 1;
static const int pcode___colordialog__METHOD_Blue = pcode___colordialog__METHOD_Green + 1;
static const int pcode___colordialog__METHOD_Alpha = pcode___colordialog__METHOD_Blue + 1;
/*
static const int pcode___colordialog__METHOD_CustomCount = pcode___colordialog__METHOD_GetColor1 + 1;
static const int pcode___colordialog__METHOD_SetCustomColor = pcode___colordialog__METHOD_CustomCount + 1;
static const int pcode___colordialog__METHOD_SetStandardColor = pcode___colordialog__METHOD_SetCustomColor + 1;
*/