case pcode___inputdialog___inputdialog: return "InputDialog";
case pcode___inputdialog__METHOD_GetDouble: return "GetDouble";
case pcode___inputdialog__METHOD_GetInteger: return "GetInteger";
case pcode___inputdialog__METHOD_GetString: return "GetString";
case pcode___inputdialog__METHOD_Ok: return "Ok";

  