static const int pcode___inputdialog___inputdialog = pcode___inputdialog * SPACE;
static const int pcode___inputdialog__METHOD_GetDouble = pcode___inputdialog___inputdialog + 1;
static const int pcode___inputdialog__METHOD_GetInteger = pcode___inputdialog__METHOD_GetDouble + 1;
static const int pcode___inputdialog__METHOD_GetString = pcode___inputdialog__METHOD_GetInteger + 1;
static const int pcode___inputdialog__METHOD_Ok = pcode___inputdialog__METHOD_GetString + 1;
