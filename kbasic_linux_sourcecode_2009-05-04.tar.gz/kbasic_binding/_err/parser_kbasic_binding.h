
new_class(pcode___err, 0, 0); 

new_method(true, pcode___err, pcode___err___err, pcode___err);
new_method(true, pcode___err, pcode___err__METHOD_Clear, pcode__VOID);
	 new_param("Number", pcode__INTEGER, false);
new_method(true, pcode___err, pcode___err__METHOD_Raise, pcode__VOID);
	 new_param("Number", pcode__INTEGER, false);
	 new_param("Source", pcode__QSTRING, false);
new_method(true, pcode___err, pcode___err__METHOD_Raise1, pcode__VOID);
	 new_param("Number", pcode__INTEGER, false);
	 new_param("Source", pcode__QSTRING, false);
	 new_param("Description", pcode__QSTRING, false);
new_method(true, pcode___err, pcode___err__METHOD_Raise2, pcode__VOID);
new_property_get(pcode___err, pcode___err__GETPROPERTY_Number, pcode__INTEGER);
new_property_get(pcode___err, pcode___err__GETPROPERTY_Source, pcode__QSTRING);
new_property_get(pcode___err, pcode___err__GETPROPERTY_Description, pcode__QSTRING);