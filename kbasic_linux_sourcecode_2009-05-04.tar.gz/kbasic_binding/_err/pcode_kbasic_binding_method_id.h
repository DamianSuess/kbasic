static const int pcode___err___err = pcode___err * SPACE;
static const int pcode___err__METHOD_Clear = pcode___err___err + 1;
static const int pcode___err__METHOD_Raise = pcode___err__METHOD_Clear + 1;
static const int pcode___err__METHOD_Raise1 = pcode___err__METHOD_Raise + 1;
static const int pcode___err__METHOD_Raise2 = pcode___err__METHOD_Raise1 + 1;
static const int pcode___err__GETPROPERTY_Number = pcode___err__METHOD_Raise2 + 1;
static const int pcode___err__GETPROPERTY_Source = pcode___err__GETPROPERTY_Number + 1;
static const int pcode___err__GETPROPERTY_Description = pcode___err__GETPROPERTY_Source + 1;
