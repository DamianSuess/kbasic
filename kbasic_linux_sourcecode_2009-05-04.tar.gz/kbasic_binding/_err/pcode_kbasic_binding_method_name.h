case pcode___err___err: return "Err2";
case pcode___err__METHOD_Clear: return "Clear";
case pcode___err__METHOD_Raise: return "Raise";
case pcode___err__METHOD_Raise1: return "METHOD_Raise";
case pcode___err__METHOD_Raise2: return "METHOD_Raise";
case pcode___err__GETPROPERTY_Number: return "GETPROPERTY_Number";
case pcode___err__GETPROPERTY_Source: return "GETPROPERTY_Source";
case pcode___err__GETPROPERTY_Description: return "GETPROPERTY_Description";
