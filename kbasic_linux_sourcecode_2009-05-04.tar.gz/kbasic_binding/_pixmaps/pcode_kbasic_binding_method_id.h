static const int pcode___pixmaps___pixmaps = pcode___pixmaps * SPACE;
static const int pcode___pixmaps__METHOD_Pixmap = pcode___pixmaps___pixmaps + 1;
static const int pcode___pixmaps__METHOD_Load = pcode___pixmaps__METHOD_Pixmap + 1;
static const int pcode___pixmaps__METHOD_SetPixmap = pcode___pixmaps__METHOD_Load + 1;

