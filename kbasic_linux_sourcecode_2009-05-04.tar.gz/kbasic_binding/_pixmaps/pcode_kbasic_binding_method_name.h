case pcode___pixmaps___pixmaps: return "Pixmaps";
case pcode___pixmaps__METHOD_Pixmap: return "Pixmap";
case pcode___pixmaps__METHOD_Load: return "Load";
case pcode___pixmaps__METHOD_SetPixmap: return "SetPixmap";
