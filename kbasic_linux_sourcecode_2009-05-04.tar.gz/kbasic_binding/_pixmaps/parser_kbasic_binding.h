
new_class(pcode___pixmaps, 0, 0); 

//new_method(true, pcode___pixmaps, pcode___pixmaps___pixmaps, pcode___pixmaps);
/*
	 new_param("Name", pcode__QString, false);
new_staticmethod(true, pcode___pixmaps, pcode___pixmaps__METHOD_Pixmap, pcode___pixmap);
*/
	 new_param("k", pcode__QString, false);
	 new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___pixmaps, pcode___pixmaps__METHOD_SetPixmap, pcode__t_boolean);


	 new_param("k", pcode__QString, false);
	 new_param("k", pcode__QString, false);
new_staticmethod(true, pcode___pixmaps, pcode___pixmaps__METHOD_Load, pcode__t_boolean);
