case pcode___event___event:{ getParam(v, m, n); pp = new kb_event(); myStack->pushParameter(pcode___event, pp); ((kb_event *) pp)->setInterpreter(this); break; }

