
new_class(pcode___event, 0, 0); 


new_method(true, pcode___event, pcode___event___event, pcode___event);
