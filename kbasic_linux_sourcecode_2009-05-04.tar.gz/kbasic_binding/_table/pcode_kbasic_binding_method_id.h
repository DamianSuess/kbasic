
static const int pcode___table___table = pcode___table * SPACE;

static const int pcode___table__METHOD_Exists = pcode___table___table + 1;
static const int pcode___table__METHOD_Exists1 = pcode___table__METHOD_Exists + 1;
static const int pcode___table__METHOD_Create = pcode___table__METHOD_Exists1 + 1;
static const int pcode___table__METHOD_Create1 = pcode___table__METHOD_Create + 1;
static const int pcode___table__METHOD_Create2 = pcode___table__METHOD_Create1 + 1;
static const int pcode___table__METHOD_Create3 = pcode___table__METHOD_Create2 + 1;
static const int pcode___table__METHOD_Clear = pcode___table__METHOD_Create3 + 1;
static const int pcode___table__METHOD_Clear1 = pcode___table__METHOD_Clear + 1;
static const int pcode___table__METHOD_Drop = pcode___table__METHOD_Clear1 + 1;
static const int pcode___table__METHOD_Drop1 = pcode___table__METHOD_Drop + 1;
static const int pcode___table__METHOD_Copy = pcode___table__METHOD_Drop1 + 1;
static const int pcode___table__METHOD_Copy1 = pcode___table__METHOD_Copy + 1;
static const int pcode___table__METHOD_Delete = pcode___table__METHOD_Copy1 + 1;
static const int pcode___table__METHOD_Delete1 = pcode___table__METHOD_Delete + 1;
static const int pcode___table__METHOD_Update = pcode___table__METHOD_Delete1 + 1;
static const int pcode___table__METHOD_Update1 = pcode___table__METHOD_Update + 1;
static const int pcode___table__METHOD_Insert = pcode___table__METHOD_Update1 + 1;
static const int pcode___table__METHOD_Insert1 = pcode___table__METHOD_Insert + 1;

static const int pcode___table__METHOD_FieldNames = pcode___table__METHOD_Insert1 + 1;
static const int pcode___table__METHOD_FieldNames1 = pcode___table__METHOD_FieldNames + 1;
static const int pcode___table__METHOD_PrimaryKeyName = pcode___table__METHOD_FieldNames1 + 1;
static const int pcode___table__METHOD_PrimaryKeyName1 = pcode___table__METHOD_PrimaryKeyName + 1;

