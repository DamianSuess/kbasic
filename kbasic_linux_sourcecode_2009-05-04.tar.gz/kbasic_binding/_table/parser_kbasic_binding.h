
new_class(pcode___table, 0, 0); 


    new_param("Database", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Exists, pcode__BOOLEAN);

    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Exists1, pcode__BOOLEAN);


    new_param("Database", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
    new_param("Fields", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Create, pcode__BOOLEAN);


    new_param("Name", pcode__QSTRING, false);
    new_param("Fields", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Create1, pcode__BOOLEAN);


    new_param("Database", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Create2, pcode__BOOLEAN);


    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Create3, pcode__BOOLEAN);


    new_param("Database", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Clear, pcode__BOOLEAN);

    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Clear1, pcode__BOOLEAN);

    new_param("Database", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Drop, pcode__BOOLEAN);

    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Drop1, pcode__BOOLEAN);

    new_param("Database", pcode__QSTRING, false);
    new_param("Source", pcode__QSTRING, false);
    new_param("Destination", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Copy, pcode__BOOLEAN);

    new_param("Source", pcode__QSTRING, false);
    new_param("Destination", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Copy1, pcode__BOOLEAN);

    new_param("Database", pcode__QSTRING, false);
    new_param("Source", pcode__QSTRING, false);
    new_param("Where", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Delete, pcode__BOOLEAN);

    new_param("Source", pcode__QSTRING, false);
    new_param("Where", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Delete1, pcode__BOOLEAN);

    new_param("Database", pcode__QSTRING, false);
    new_param("Source", pcode__QSTRING, false);
    new_param("Update", pcode___array, false);
    new_param("Where", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Update, pcode__BOOLEAN);

    new_param("Source", pcode__QSTRING, false);
    new_param("Update", pcode___array, false);
    new_param("Where", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Update1, pcode__BOOLEAN);

    new_param("Database", pcode__QSTRING, false);
    new_param("Source", pcode__QSTRING, false);
    new_param("Insert", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Insert, pcode__BOOLEAN);

    new_param("Source", pcode__QSTRING, false);
    new_param("Insert", pcode___array, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_Insert1, pcode__BOOLEAN);


    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_FieldNames, pcode___strings);

    new_param("Database", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_FieldNames1, pcode___strings);

    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_PrimaryKeyName, pcode__QSTRING);

    new_param("Database", pcode__QSTRING, false);
    new_param("Name", pcode__QSTRING, false);
new_staticmethod(true, pcode___table, pcode___table__METHOD_PrimaryKeyName1, pcode__QSTRING);

