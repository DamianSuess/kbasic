case pcode___table___table: return "Table";

case pcode___table__METHOD_Exists: return "Exists";
case pcode___table__METHOD_Exists1: return "Exists1";
case pcode___table__METHOD_Create: return "Create";
case pcode___table__METHOD_Create1: return "Create1";
case pcode___table__METHOD_Create2: return "Create2";
case pcode___table__METHOD_Create3: return "Create3";
case pcode___table__METHOD_Clear: return "Empty";
case pcode___table__METHOD_Clear1: return "Empty1";
case pcode___table__METHOD_Drop: return "Drop";
case pcode___table__METHOD_Drop1: return "Drop1";
case pcode___table__METHOD_Copy: return "Copy";
case pcode___table__METHOD_Copy1: return "Copy1";
case pcode___table__METHOD_Delete: return "Delete";
case pcode___table__METHOD_Delete1: return "Delete1";
case pcode___table__METHOD_Update: return "Update";
case pcode___table__METHOD_Update1: return "Update1";
case pcode___table__METHOD_Insert: return "Insert";
case pcode___table__METHOD_Insert1: return "Insert1";

case pcode___table__METHOD_FieldNames: return "FieldNames";
case pcode___table__METHOD_FieldNames1: return "FieldNames1";
case pcode___table__METHOD_PrimaryKeyName: return "PrimaryKeyName";
case pcode___table__METHOD_PrimaryKeyName1: return "PrimaryKeyName1";
