
new_class(pcode___toolbar, 0, 0); 

new_method(true, pcode___toolbar, pcode___toolbar___toolbar, pcode___toolbar);


	 new_param("Tag", pcode__QString, false);
	 new_param("PropertyName", pcode__QString, false);
	 new_param("Value", pcode__t_boolean, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_SetWithTag, pcode__VOID);

	 new_param("Tag", pcode__QString, false);
	 new_param("PropertyName", pcode__QString, false);
	 new_param("Value", pcode__t_integer, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_SetWithTag1, pcode__VOID);

	 new_param("Tag", pcode__QString, false);
	 new_param("PropertyName", pcode__QString, false);
	 new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_SetWithTag2, pcode__VOID);


	 new_param("Group", pcode__QString, false);
	 new_param("PropertyName", pcode__QString, false);
	 new_param("Value", pcode__t_boolean, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_SetWithGroup, pcode__VOID);

	 new_param("Group", pcode__QString, false);
	 new_param("PropertyName", pcode__QString, false);
	 new_param("Value", pcode__t_integer, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_SetWithGroup1, pcode__VOID);

	 new_param("Group", pcode__QString, false);
	 new_param("PropertyName", pcode__QString, false);
	 new_param("Value", pcode__QString, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_SetWithGroup2, pcode__VOID);



	 new_param("Name", pcode__QString, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_ToolBarItem, pcode___toolbaritem);

	 new_param("Index", pcode__t_integer, false);
	 new_param("Control", pcode___control, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_InsertControl, pcode__VOID);


	 new_param("Visible", pcode__t_boolean, false);
new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_SetVisible, pcode__VOID);

new_staticmethod(true, pcode___toolbar, pcode___toolbar__METHOD_IsVisible, pcode__t_boolean);

