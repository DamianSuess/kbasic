case pcode___toolbar___toolbar: return "ToolBar";
case pcode___toolbar__METHOD_ToolBarItem: return "ToolBarItem";
case pcode___toolbar__METHOD_InsertControl: return "InsertControl";
case pcode___toolbar__METHOD_SetVisible: return "SetVisible";
case pcode___toolbar__METHOD_IsVisible: return "IsVisible";


case pcode___toolbar__METHOD_SetWithTag: return "SetWithTag";
case pcode___toolbar__METHOD_SetWithTag1: return "SetWithTag1";
case pcode___toolbar__METHOD_SetWithTag2: return "SetWithTag2";

case pcode___toolbar__METHOD_SetWithGroup: return "SetWithGroup";
case pcode___toolbar__METHOD_SetWithGroup1: return "SetWithGroup1";
case pcode___toolbar__METHOD_SetWithGroup2: return "SetWithGroup2";
