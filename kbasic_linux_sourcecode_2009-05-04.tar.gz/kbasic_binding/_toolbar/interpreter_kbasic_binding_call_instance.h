case pcode___toolbar___toolbar:{ getParam(v, m, n); pp = new kb_toolbar(); myStack->pushParameter(pcode___toolbar, pp); ((kb_toolbar *) pp)->setInterpreter(this); break; }
