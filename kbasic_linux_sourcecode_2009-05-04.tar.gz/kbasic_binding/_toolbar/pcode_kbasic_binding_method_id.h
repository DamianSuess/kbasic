static const int pcode___toolbar___toolbar = pcode___toolbar * SPACE;
static const int pcode___toolbar__METHOD_ToolBarItem = pcode___toolbar___toolbar + 1;
static const int pcode___toolbar__METHOD_InsertControl = pcode___toolbar__METHOD_ToolBarItem + 1;
static const int pcode___toolbar__METHOD_SetVisible = pcode___toolbar__METHOD_InsertControl + 1;
static const int pcode___toolbar__METHOD_IsVisible = pcode___toolbar__METHOD_SetVisible + 1;


static const int pcode___toolbar__METHOD_SetWithTag = pcode___toolbar__METHOD_IsVisible + 1;
static const int pcode___toolbar__METHOD_SetWithTag1 = pcode___toolbar__METHOD_SetWithTag + 1;
static const int pcode___toolbar__METHOD_SetWithTag2 = pcode___toolbar__METHOD_SetWithTag1 + 1;

static const int pcode___toolbar__METHOD_SetWithGroup = pcode___toolbar__METHOD_SetWithTag2 + 1;
static const int pcode___toolbar__METHOD_SetWithGroup1 = pcode___toolbar__METHOD_SetWithGroup + 1;
static const int pcode___toolbar__METHOD_SetWithGroup2 = pcode___toolbar__METHOD_SetWithGroup1 + 1;


