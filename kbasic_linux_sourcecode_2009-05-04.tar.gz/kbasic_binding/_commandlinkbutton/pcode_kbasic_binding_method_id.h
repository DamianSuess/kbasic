static const int pcode___commandlinkbutton___commandlinkbutton = pcode___commandlinkbutton * SPACE;
static const int pcode___commandlinkbutton___commandlinkbutton1 = pcode___commandlinkbutton___commandlinkbutton + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_MouseTracking = pcode___commandlinkbutton___commandlinkbutton1 + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_MouseTracking = pcode___commandlinkbutton__SETPROPERTY_MouseTracking + 1; 



static const int pcode___commandlinkbutton__EVENT_OnSingleShot = pcode___commandlinkbutton__GETPROPERTY_MouseTracking + 1;
static const int pcode___commandlinkbutton__EVENT_OnEnabled = pcode___commandlinkbutton__EVENT_OnSingleShot + 1;
static const int pcode___commandlinkbutton__EVENT_OnDisabled = pcode___commandlinkbutton__EVENT_OnEnabled + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_CursorAnimation = pcode___commandlinkbutton__EVENT_OnDisabled + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_CursorAnimation = pcode___commandlinkbutton__SETPROPERTY_CursorAnimation + 1; 

static const int pcode___commandlinkbutton__METHOD_DataIds = pcode___commandlinkbutton__GETPROPERTY_CursorAnimation + 1;

static const int pcode___commandlinkbutton__METHOD_DataRemove = pcode___commandlinkbutton__METHOD_DataIds + 1;
static const int pcode___commandlinkbutton__METHOD_DataRemoveAll = pcode___commandlinkbutton__METHOD_DataRemove + 1;
static const int pcode___commandlinkbutton__METHOD_DataSetBoolean = pcode___commandlinkbutton__METHOD_DataRemoveAll + 1;
static const int pcode___commandlinkbutton__METHOD_DataSetInteger = pcode___commandlinkbutton__METHOD_DataSetBoolean + 1;
static const int pcode___commandlinkbutton__METHOD_DataSetString = pcode___commandlinkbutton__METHOD_DataSetInteger + 1;
static const int pcode___commandlinkbutton__METHOD_DataSetDouble = pcode___commandlinkbutton__METHOD_DataSetString + 1;
static const int pcode___commandlinkbutton__METHOD_DataSetLong = pcode___commandlinkbutton__METHOD_DataSetDouble + 1;
static const int pcode___commandlinkbutton__METHOD_DataSetDecimal = pcode___commandlinkbutton__METHOD_DataSetLong + 1;
static const int pcode___commandlinkbutton__METHOD_DataSetDateTime = pcode___commandlinkbutton__METHOD_DataSetDecimal + 1;


static const int pcode___commandlinkbutton__METHOD_DataBoolean = pcode___commandlinkbutton__METHOD_DataSetDateTime + 1;
static const int pcode___commandlinkbutton__METHOD_DataInteger = pcode___commandlinkbutton__METHOD_DataBoolean + 1;
static const int pcode___commandlinkbutton__METHOD_DataString = pcode___commandlinkbutton__METHOD_DataInteger + 1;
static const int pcode___commandlinkbutton__METHOD_DataDouble = pcode___commandlinkbutton__METHOD_DataString + 1;
static const int pcode___commandlinkbutton__METHOD_DataLong = pcode___commandlinkbutton__METHOD_DataDouble + 1;
static const int pcode___commandlinkbutton__METHOD_DataDecimal = pcode___commandlinkbutton__METHOD_DataLong + 1;
static const int pcode___commandlinkbutton__METHOD_DataDateTime = pcode___commandlinkbutton__METHOD_DataDecimal + 1;

static const int pcode___commandlinkbutton__METHOD_ClearFocus = pcode___commandlinkbutton__METHOD_DataDateTime + 1;
static const int pcode___commandlinkbutton__METHOD_ToggleVisible = pcode___commandlinkbutton__METHOD_ClearFocus + 1;

static const int pcode___commandlinkbutton__METHOD_SingleShot = pcode___commandlinkbutton__METHOD_ToggleVisible + 1;
static const int pcode___commandlinkbutton__METHOD_StartTimer = pcode___commandlinkbutton__METHOD_SingleShot + 1;
static const int pcode___commandlinkbutton__METHOD_StopTimer = pcode___commandlinkbutton__METHOD_StartTimer + 1;

//static const int pcode___commandlinkbutton__METHOD_EventSender = pcode___commandlinkbutton__METHOD_StopTimer + 1;

static const int pcode___commandlinkbutton__METHOD_GlobalX = pcode___commandlinkbutton__METHOD_StopTimer + 1;
static const int pcode___commandlinkbutton__METHOD_GlobalY = pcode___commandlinkbutton__METHOD_GlobalX + 1;
static const int pcode___commandlinkbutton__METHOD_LocalX = pcode___commandlinkbutton__METHOD_GlobalY + 1;
static const int pcode___commandlinkbutton__METHOD_LocalY = pcode___commandlinkbutton__METHOD_LocalX + 1;

static const int pcode___commandlinkbutton__METHOD_UnderMouse = pcode___commandlinkbutton__METHOD_LocalY + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_Mask = pcode___commandlinkbutton__METHOD_UnderMouse + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Mask = pcode___commandlinkbutton__SETPROPERTY_Mask + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_SoundOnEvent = pcode___commandlinkbutton__GETPROPERTY_Mask + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_SoundOnEvent = pcode___commandlinkbutton__SETPROPERTY_SoundOnEvent + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_Left = pcode___commandlinkbutton__GETPROPERTY_SoundOnEvent + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Left = pcode___commandlinkbutton__SETPROPERTY_Left + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Top = pcode___commandlinkbutton__GETPROPERTY_Left + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Top = pcode___commandlinkbutton__SETPROPERTY_Top + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_LocalX = pcode___commandlinkbutton__GETPROPERTY_Top + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_LocalX = pcode___commandlinkbutton__SETPROPERTY_LocalX + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_LocalY = pcode___commandlinkbutton__GETPROPERTY_LocalX + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_LocalY = pcode___commandlinkbutton__SETPROPERTY_LocalY + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_DrawOnPaint = pcode___commandlinkbutton__GETPROPERTY_LocalY + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_DrawOnPaint = pcode___commandlinkbutton__SETPROPERTY_DrawOnPaint + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_Palette = pcode___commandlinkbutton__GETPROPERTY_DrawOnPaint + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Palette = pcode___commandlinkbutton__SETPROPERTY_Palette + 1;


static const int pcode___commandlinkbutton__SETPROPERTY_BackgroundStyle = pcode___commandlinkbutton__GETPROPERTY_Palette + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_BackgroundStyle = pcode___commandlinkbutton__SETPROPERTY_BackgroundStyle + 1;




static const int pcode___commandlinkbutton__SETPROPERTY_ContextMenu = pcode___commandlinkbutton__GETPROPERTY_BackgroundStyle + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ContextMenu = pcode___commandlinkbutton__SETPROPERTY_ContextMenu + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Layout = pcode___commandlinkbutton__GETPROPERTY_ContextMenu + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Layout = pcode___commandlinkbutton__SETPROPERTY_Layout + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_Caption = pcode___commandlinkbutton__GETPROPERTY_Layout + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Caption = pcode___commandlinkbutton__SETPROPERTY_Caption + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Value = pcode___commandlinkbutton__GETPROPERTY_Caption + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Value = pcode___commandlinkbutton__SETPROPERTY_Value + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Text = pcode___commandlinkbutton__GETPROPERTY_Value + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Text = pcode___commandlinkbutton__SETPROPERTY_Text + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Description = pcode___commandlinkbutton__GETPROPERTY_Text + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Description = pcode___commandlinkbutton__SETPROPERTY_Description + 1;



static const int pcode___commandlinkbutton__SETPROPERTY_Checkable = pcode___commandlinkbutton__GETPROPERTY_Description + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Checkable = pcode___commandlinkbutton__SETPROPERTY_Checkable + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_Checked = pcode___commandlinkbutton__GETPROPERTY_Checkable + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Checked = pcode___commandlinkbutton__SETPROPERTY_Checked + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_AutoDefault = pcode___commandlinkbutton__GETPROPERTY_Checked + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_AutoDefault = pcode___commandlinkbutton__SETPROPERTY_AutoDefault + 1;

static const int pcode___commandlinkbutton__SETPROPERTY_Icon = pcode___commandlinkbutton__GETPROPERTY_AutoDefault + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Icon = pcode___commandlinkbutton__SETPROPERTY_Icon + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Key = pcode___commandlinkbutton__GETPROPERTY_Icon + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Key = pcode___commandlinkbutton__SETPROPERTY_Key + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Default = pcode___commandlinkbutton__GETPROPERTY_Key + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Default = pcode___commandlinkbutton__SETPROPERTY_Default + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Flat = pcode___commandlinkbutton__GETPROPERTY_Default + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Flat = pcode___commandlinkbutton__SETPROPERTY_Flat + 1;
static const int pcode___commandlinkbutton__EVENT_OnEvent = pcode___commandlinkbutton__GETPROPERTY_Flat + 1;
static const int pcode___commandlinkbutton__METHOD_Move = pcode___commandlinkbutton__EVENT_OnEvent + 1;
static const int pcode___commandlinkbutton__METHOD_Resize = pcode___commandlinkbutton__METHOD_Move + 1;
static const int pcode___commandlinkbutton__METHOD_Show = pcode___commandlinkbutton__METHOD_Resize + 1;
static const int pcode___commandlinkbutton__METHOD_Hide = pcode___commandlinkbutton__METHOD_Show + 1;
static const int pcode___commandlinkbutton__METHOD_RepaintAlways = pcode___commandlinkbutton__METHOD_Hide + 1;
static const int pcode___commandlinkbutton__METHOD_Repaint = pcode___commandlinkbutton__METHOD_RepaintAlways + 1;
static const int pcode___commandlinkbutton__METHOD_Raise = pcode___commandlinkbutton__METHOD_Repaint + 1;
static const int pcode___commandlinkbutton__METHOD_Lower = pcode___commandlinkbutton__METHOD_Raise + 1;
static const int pcode___commandlinkbutton__METHOD_Close = pcode___commandlinkbutton__METHOD_Lower + 1;
static const int pcode___commandlinkbutton__METHOD_Open = pcode___commandlinkbutton__METHOD_Close + 1;
static const int pcode___commandlinkbutton__METHOD_SetFocus = pcode___commandlinkbutton__METHOD_Open + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Name = pcode___commandlinkbutton__METHOD_SetFocus + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Name = pcode___commandlinkbutton__SETPROPERTY_Name + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Group = pcode___commandlinkbutton__GETPROPERTY_Name + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Group = pcode___commandlinkbutton__SETPROPERTY_Group + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Background = pcode___commandlinkbutton__GETPROPERTY_Group + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Background = pcode___commandlinkbutton__SETPROPERTY_Background + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_X = pcode___commandlinkbutton__GETPROPERTY_Background + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_X = pcode___commandlinkbutton__SETPROPERTY_X + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Y = pcode___commandlinkbutton__GETPROPERTY_X + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Y = pcode___commandlinkbutton__SETPROPERTY_Y + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Width = pcode___commandlinkbutton__GETPROPERTY_Y + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Width = pcode___commandlinkbutton__SETPROPERTY_Width + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Height = pcode___commandlinkbutton__GETPROPERTY_Width + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Height = pcode___commandlinkbutton__SETPROPERTY_Height + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_GlobalX = pcode___commandlinkbutton__GETPROPERTY_Height + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_GlobalY = pcode___commandlinkbutton__GETPROPERTY_GlobalX + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_OldX = pcode___commandlinkbutton__GETPROPERTY_GlobalY + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_OldY = pcode___commandlinkbutton__GETPROPERTY_OldX + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_OldWidth = pcode___commandlinkbutton__GETPROPERTY_OldY + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_OldHeight = pcode___commandlinkbutton__GETPROPERTY_OldWidth + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_MinimumWidth = pcode___commandlinkbutton__GETPROPERTY_OldHeight + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_MinimumWidth = pcode___commandlinkbutton__SETPROPERTY_MinimumWidth + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_MinimumHeight = pcode___commandlinkbutton__GETPROPERTY_MinimumWidth + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_MinimumHeight = pcode___commandlinkbutton__SETPROPERTY_MinimumHeight + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_MaximumWidth = pcode___commandlinkbutton__GETPROPERTY_MinimumHeight + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_MaximumWidth = pcode___commandlinkbutton__SETPROPERTY_MaximumWidth + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_MaximumHeight = pcode___commandlinkbutton__GETPROPERTY_MaximumWidth + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_MaximumHeight = pcode___commandlinkbutton__SETPROPERTY_MaximumHeight + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Tag = pcode___commandlinkbutton__GETPROPERTY_MaximumHeight + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Tag = pcode___commandlinkbutton__SETPROPERTY_Tag + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_CSV = pcode___commandlinkbutton__GETPROPERTY_Tag + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_CSV = pcode___commandlinkbutton__SETPROPERTY_CSV + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_ParentForm = pcode___commandlinkbutton__GETPROPERTY_CSV + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ParentForm = pcode___commandlinkbutton__SETPROPERTY_ParentForm + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_ParentControl = pcode___commandlinkbutton__GETPROPERTY_ParentForm + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ParentControl = pcode___commandlinkbutton__SETPROPERTY_ParentControl + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_DragDrop = pcode___commandlinkbutton__GETPROPERTY_ParentControl + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ParentControl1 = pcode___commandlinkbutton__SETPROPERTY_DragDrop + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_ControlType = pcode___commandlinkbutton__GETPROPERTY_ParentControl1 + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ControlType = pcode___commandlinkbutton__SETPROPERTY_ControlType + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Focus = pcode___commandlinkbutton__GETPROPERTY_ControlType + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Focus = pcode___commandlinkbutton__SETPROPERTY_Focus + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FocusPolicy = pcode___commandlinkbutton__GETPROPERTY_Focus + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FocusPolicy = pcode___commandlinkbutton__SETPROPERTY_FocusPolicy + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FocusProxy = pcode___commandlinkbutton__GETPROPERTY_FocusPolicy + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FocusProxy = pcode___commandlinkbutton__SETPROPERTY_FocusProxy + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FocusOrder = pcode___commandlinkbutton__GETPROPERTY_FocusProxy + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FocusOrder = pcode___commandlinkbutton__SETPROPERTY_FocusOrder + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Cursor = pcode___commandlinkbutton__GETPROPERTY_FocusOrder + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Cursor = pcode___commandlinkbutton__SETPROPERTY_Cursor + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FontName = pcode___commandlinkbutton__GETPROPERTY_Cursor + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FontName = pcode___commandlinkbutton__SETPROPERTY_FontName + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FontSize = pcode___commandlinkbutton__GETPROPERTY_FontName + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FontSize = pcode___commandlinkbutton__SETPROPERTY_FontSize + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FontItalic = pcode___commandlinkbutton__GETPROPERTY_FontSize + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FontItalic = pcode___commandlinkbutton__SETPROPERTY_FontItalic + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FontBold = pcode___commandlinkbutton__GETPROPERTY_FontItalic + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FontBold = pcode___commandlinkbutton__SETPROPERTY_FontBold + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FontUnderline = pcode___commandlinkbutton__GETPROPERTY_FontBold + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FontUnderline = pcode___commandlinkbutton__SETPROPERTY_FontUnderline + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_FontColor = pcode___commandlinkbutton__GETPROPERTY_FontUnderline + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_FontColor = pcode___commandlinkbutton__SETPROPERTY_FontColor + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Enabled = pcode___commandlinkbutton__GETPROPERTY_FontColor + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Enabled = pcode___commandlinkbutton__SETPROPERTY_Enabled + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Visible = pcode___commandlinkbutton__GETPROPERTY_Enabled + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Visible = pcode___commandlinkbutton__SETPROPERTY_Visible + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_StatusTip = pcode___commandlinkbutton__GETPROPERTY_Visible + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_StatusTip = pcode___commandlinkbutton__SETPROPERTY_StatusTip + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_ToolTip = pcode___commandlinkbutton__GETPROPERTY_StatusTip + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ToolTip = pcode___commandlinkbutton__SETPROPERTY_ToolTip + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_StyleSheet = pcode___commandlinkbutton__GETPROPERTY_ToolTip + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_StyleSheet = pcode___commandlinkbutton__SETPROPERTY_StyleSheet + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_WhatsThis = pcode___commandlinkbutton__GETPROPERTY_StyleSheet + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_WhatsThis = pcode___commandlinkbutton__SETPROPERTY_WhatsThis + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_TimerInterval = pcode___commandlinkbutton__GETPROPERTY_WhatsThis + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_TimerInterval = pcode___commandlinkbutton__SETPROPERTY_TimerInterval + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_Opacity = pcode___commandlinkbutton__GETPROPERTY_TimerInterval + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_Opacity = pcode___commandlinkbutton__SETPROPERTY_Opacity + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_BoxIndex = pcode___commandlinkbutton__GETPROPERTY_Opacity + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_BoxIndex = pcode___commandlinkbutton__SETPROPERTY_BoxIndex + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_SplitIndex = pcode___commandlinkbutton__GETPROPERTY_BoxIndex + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_SplitIndex = pcode___commandlinkbutton__SETPROPERTY_SplitIndex + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_TabIndex = pcode___commandlinkbutton__GETPROPERTY_SplitIndex + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_TabIndex = pcode___commandlinkbutton__SETPROPERTY_TabIndex + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_BoxX = pcode___commandlinkbutton__GETPROPERTY_TabIndex + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_BoxX = pcode___commandlinkbutton__SETPROPERTY_BoxX + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_BoxY = pcode___commandlinkbutton__GETPROPERTY_BoxX + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_BoxY = pcode___commandlinkbutton__SETPROPERTY_BoxY + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_ParentIndex = pcode___commandlinkbutton__GETPROPERTY_BoxY + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ParentIndex = pcode___commandlinkbutton__SETPROPERTY_ParentIndex + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_ControlType1 = pcode___commandlinkbutton__GETPROPERTY_ParentIndex + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_ControlType1 = pcode___commandlinkbutton__SETPROPERTY_ControlType1 + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_SQLName = pcode___commandlinkbutton__GETPROPERTY_ControlType1 + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_SQLName = pcode___commandlinkbutton__SETPROPERTY_SQLName + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_SQLType = pcode___commandlinkbutton__GETPROPERTY_SQLName + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_SQLType = pcode___commandlinkbutton__SETPROPERTY_SQLType + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_SQLCaption = pcode___commandlinkbutton__GETPROPERTY_SQLType + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_SQLCaption = pcode___commandlinkbutton__SETPROPERTY_SQLCaption + 1;
static const int pcode___commandlinkbutton__SETPROPERTY_SQLWidth = pcode___commandlinkbutton__GETPROPERTY_SQLCaption + 1;
static const int pcode___commandlinkbutton__GETPROPERTY_SQLWidth = pcode___commandlinkbutton__SETPROPERTY_SQLWidth + 1;
static const int pcode___commandlinkbutton__EVENT_OnOpen = pcode___commandlinkbutton__GETPROPERTY_SQLWidth + 1;
static const int pcode___commandlinkbutton__EVENT_OnClose = pcode___commandlinkbutton__EVENT_OnOpen + 1;
static const int pcode___commandlinkbutton__EVENT_OnContextMenu = pcode___commandlinkbutton__EVENT_OnClose + 1;
static const int pcode___commandlinkbutton__EVENT_OnDragEnter = pcode___commandlinkbutton__EVENT_OnContextMenu + 1;
static const int pcode___commandlinkbutton__EVENT_OnDragExit = pcode___commandlinkbutton__EVENT_OnDragEnter + 1;
static const int pcode___commandlinkbutton__EVENT_OnDragMove = pcode___commandlinkbutton__EVENT_OnDragExit + 1;
static const int pcode___commandlinkbutton__EVENT_OnDrop = pcode___commandlinkbutton__EVENT_OnDragMove + 1;
static const int pcode___commandlinkbutton__EVENT_OnEnter = pcode___commandlinkbutton__EVENT_OnDrop + 1;
static const int pcode___commandlinkbutton__EVENT_OnGotFocus = pcode___commandlinkbutton__EVENT_OnEnter + 1;
static const int pcode___commandlinkbutton__EVENT_OnLostFocus = pcode___commandlinkbutton__EVENT_OnGotFocus + 1;
static const int pcode___commandlinkbutton__EVENT_OnHide = pcode___commandlinkbutton__EVENT_OnLostFocus + 1;
static const int pcode___commandlinkbutton__EVENT_OnKeyDown = pcode___commandlinkbutton__EVENT_OnHide + 1;
static const int pcode___commandlinkbutton__EVENT_OnKeyUp = pcode___commandlinkbutton__EVENT_OnKeyDown + 1;
static const int pcode___commandlinkbutton__EVENT_OnKeyPress = pcode___commandlinkbutton__EVENT_OnKeyUp + 1;
static const int pcode___commandlinkbutton__EVENT_OnExit = pcode___commandlinkbutton__EVENT_OnKeyPress + 1;
static const int pcode___commandlinkbutton__EVENT_OnDblClick = pcode___commandlinkbutton__EVENT_OnExit + 1;
static const int pcode___commandlinkbutton__EVENT_OnClick = pcode___commandlinkbutton__EVENT_OnDblClick + 1;
static const int pcode___commandlinkbutton__EVENT_OnMouseMove = pcode___commandlinkbutton__EVENT_OnClick + 1;
static const int pcode___commandlinkbutton__EVENT_OnMouseDown = pcode___commandlinkbutton__EVENT_OnMouseMove + 1;
static const int pcode___commandlinkbutton__EVENT_OnMouseUp = pcode___commandlinkbutton__EVENT_OnMouseDown + 1;
static const int pcode___commandlinkbutton__EVENT_OnMove = pcode___commandlinkbutton__EVENT_OnMouseUp + 1;
static const int pcode___commandlinkbutton__EVENT_OnPaint = pcode___commandlinkbutton__EVENT_OnMove + 1;
static const int pcode___commandlinkbutton__EVENT_OnResize = pcode___commandlinkbutton__EVENT_OnPaint + 1;
static const int pcode___commandlinkbutton__EVENT_OnShow = pcode___commandlinkbutton__EVENT_OnResize + 1;
static const int pcode___commandlinkbutton__EVENT_OnMouseWheel = pcode___commandlinkbutton__EVENT_OnShow + 1;
static const int pcode___commandlinkbutton__EVENT_OnTimer = pcode___commandlinkbutton__EVENT_OnMouseWheel + 1;
static const int pcode___commandlinkbutton__EVENT_OnPrint = pcode___commandlinkbutton__EVENT_OnTimer + 1;