case pcode___statusbar___statusbar:{ getParam(v, m, n); pp = new kb_statusbar(); myStack->pushParameter(pcode___statusbar, pp); ((kb_statusbar *) pp)->setInterpreter(this); break; }
