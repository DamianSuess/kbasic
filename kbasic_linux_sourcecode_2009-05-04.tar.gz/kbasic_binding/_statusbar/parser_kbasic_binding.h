
new_class(pcode___statusbar, 0, 0); 

new_method(true, pcode___statusbar, pcode___statusbar___statusbar, pcode___statusbar);

new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_Clear, pcode__VOID);
   
   new_param("Control", pcode___control, false);
new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_Remove, pcode__VOID);

	 new_param("Index", pcode__t_integer, false);
	 new_param("Control", pcode___control, false);
new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_InsertControl, pcode__VOID);

	 new_param("Index", pcode__t_integer, false);
	 new_param("Control", pcode___control, false);
	 new_param("Stretch", pcode__t_integer, false);
new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_InsertControl1, pcode__VOID);

	 new_param("Text", pcode__QString, false);
new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_Print, pcode__VOID);

	 new_param("Text", pcode__QString, false);
	 new_param("TimeOutInMilliSeconds", pcode__t_integer, false);
new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_Print1, pcode__VOID);

new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_Open, pcode__VOID);
   
new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_Close, pcode__VOID);
   
new_staticmethod(true, pcode___statusbar, pcode___statusbar__METHOD_Toggle, pcode__VOID);
   