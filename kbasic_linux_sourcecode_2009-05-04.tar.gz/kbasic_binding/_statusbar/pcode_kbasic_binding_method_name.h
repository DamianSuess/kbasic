case pcode___statusbar___statusbar: return "StatusBar";

case pcode___statusbar__METHOD_Clear: return "Clear";
case pcode___statusbar__METHOD_Remove: return "RemoveControl";
case pcode___statusbar__METHOD_InsertControl: return "InsertControl";
case pcode___statusbar__METHOD_InsertControl1: return "InsertControl1";
case pcode___statusbar__METHOD_Print: return "Print";
case pcode___statusbar__METHOD_Print1: return "Print1";
case pcode___statusbar__METHOD_Open: return "Show";
case pcode___statusbar__METHOD_Close: return "Hide";
case pcode___statusbar__METHOD_Toggle: return "ToggleVisible";
