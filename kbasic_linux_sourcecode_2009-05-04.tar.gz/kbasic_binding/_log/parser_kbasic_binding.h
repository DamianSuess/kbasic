
new_class(pcode___log, 0, 0); 


	 new_param("Text", pcode__QString, false);
new_staticmethod(true, pcode___log, pcode___log__METHOD_Print, pcode__VOID);

	 new_param("Text", pcode__QString, false);
new_staticmethod(true, pcode___log, pcode___log__METHOD_PrintHtml, pcode__VOID);

	 new_param("Text", pcode__QString, false);
new_staticmethod(true, pcode___log, pcode___log__METHOD_PrintSql, pcode__VOID);

new_staticmethod(true, pcode___log, pcode___log__METHOD_Show, pcode__VOID);
new_staticmethod(true, pcode___log, pcode___log__METHOD_ShowMaximized, pcode__VOID);
new_staticmethod(true, pcode___log, pcode___log__METHOD_ShowMinimized, pcode__VOID);
new_staticmethod(true, pcode___log, pcode___log__METHOD_Hide, pcode__VOID);
new_staticmethod(true, pcode___log, pcode___log__METHOD_Clear, pcode__VOID);


