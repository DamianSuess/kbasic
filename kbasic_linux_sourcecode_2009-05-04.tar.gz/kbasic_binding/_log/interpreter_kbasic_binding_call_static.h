

case pcode___log__METHOD_Print:{ _log::METHOD_Print(v[0]->toQString()); break; }
case pcode___log__METHOD_PrintHtml:{ _log::METHOD_PrintHtml(v[0]->toQString()); break; }
case pcode___log__METHOD_PrintSql:{ _log::METHOD_PrintSql(v[0]->toQString()); break; }

case pcode___log__METHOD_Show:{ _log::METHOD_Show(); break; }
case pcode___log__METHOD_ShowMaximized:{ _log::METHOD_ShowMaximized(); break; }
case pcode___log__METHOD_ShowMinimized:{ _log::METHOD_ShowMinimized(); break; }
case pcode___log__METHOD_Hide:{ _log::METHOD_Hide(); break; }
case pcode___log__METHOD_Clear:{ _log::METHOD_Clear(); break; }
