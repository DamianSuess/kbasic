

static const int pcode___log___log = pcode___log * SPACE;
static const int pcode___log__METHOD_Print = pcode___log___log + 1;
static const int pcode___log__METHOD_PrintHtml = pcode___log__METHOD_Print + 1;
static const int pcode___log__METHOD_PrintSql = pcode___log__METHOD_PrintHtml + 1;
static const int pcode___log__METHOD_Show = pcode___log__METHOD_PrintSql + 1;
static const int pcode___log__METHOD_ShowMaximized = pcode___log__METHOD_Show + 1;
static const int pcode___log__METHOD_ShowMinimized = pcode___log__METHOD_ShowMaximized + 1;
static const int pcode___log__METHOD_Hide = pcode___log__METHOD_ShowMinimized + 1;
static const int pcode___log__METHOD_Clear = pcode___log__METHOD_Hide + 1;


