
case pcode___log___log: return "LOG";
case pcode___log__METHOD_Print: return "Print";
case pcode___log__METHOD_PrintHtml: return "PrintHtml";
case pcode___log__METHOD_PrintSql: return "PrintSql";
case pcode___log__METHOD_Show: return "Show";
case pcode___log__METHOD_ShowMaximized: return "ShowMaximized";
case pcode___log__METHOD_ShowMinimized: return "ShowMinimized";
case pcode___log__METHOD_Hide: return "Hide";
case pcode___log__METHOD_Clear: return "Clear";
