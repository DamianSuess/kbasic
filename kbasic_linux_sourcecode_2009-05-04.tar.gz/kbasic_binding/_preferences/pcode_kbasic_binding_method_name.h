case pcode___preferences___preferences: return "Preferences";

case pcode___preferences__METHOD_Has: return "Has";
case pcode___preferences__METHOD_Remove: return "Remove";
case pcode___preferences__METHOD_Load: return "Load";
case pcode___preferences__METHOD_Save: return "Save";
case pcode___preferences__METHOD_Ids: return "Ids";
case pcode___preferences__METHOD_SetBoolean: return "SetBoolean";
case pcode___preferences__METHOD_SetInteger: return "SetInteger";
case pcode___preferences__METHOD_SetString: return "SetString";
case pcode___preferences__METHOD_SetDouble: return "SetDouble";
case pcode___preferences__METHOD_Boolean: return "Boolean";
case pcode___preferences__METHOD_Integer: return "Integer";
case pcode___preferences__METHOD_String: return "String";
case pcode___preferences__METHOD_Double: return "Double";
