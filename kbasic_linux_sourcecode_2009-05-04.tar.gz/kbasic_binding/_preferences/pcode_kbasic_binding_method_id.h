static const int pcode___preferences___preferences = pcode___preferences * SPACE;

static const int pcode___preferences__METHOD_Has = pcode___preferences___preferences + 1;
static const int pcode___preferences__METHOD_Remove = pcode___preferences__METHOD_Has + 1;
static const int pcode___preferences__METHOD_Load = pcode___preferences__METHOD_Remove + 1;
static const int pcode___preferences__METHOD_Save = pcode___preferences__METHOD_Load + 1;
static const int pcode___preferences__METHOD_Ids = pcode___preferences__METHOD_Save + 1;
static const int pcode___preferences__METHOD_SetBoolean = pcode___preferences__METHOD_Ids + 1;
static const int pcode___preferences__METHOD_SetInteger = pcode___preferences__METHOD_SetBoolean + 1;
static const int pcode___preferences__METHOD_SetString = pcode___preferences__METHOD_SetInteger + 1;
static const int pcode___preferences__METHOD_SetDouble = pcode___preferences__METHOD_SetString + 1;
static const int pcode___preferences__METHOD_Boolean = pcode___preferences__METHOD_SetDouble + 1;
static const int pcode___preferences__METHOD_Integer = pcode___preferences__METHOD_Boolean + 1;
static const int pcode___preferences__METHOD_String = pcode___preferences__METHOD_Integer + 1;
static const int pcode___preferences__METHOD_Double = pcode___preferences__METHOD_String + 1;
