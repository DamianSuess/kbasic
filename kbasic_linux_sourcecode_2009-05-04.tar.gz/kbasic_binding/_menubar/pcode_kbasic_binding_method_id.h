static const int pcode___menubar___menubar = pcode___menubar * SPACE;
static const int pcode___menubar___menubar1 = pcode___menubar___menubar * SPACE;
static const int pcode___menubar__METHOD_MenuBarItem = pcode___menubar___menubar1 + 1;
static const int pcode___menubar__METHOD_SetVisible = pcode___menubar__METHOD_MenuBarItem + 1;
static const int pcode___menubar__METHOD_IsVisible = pcode___menubar__METHOD_SetVisible + 1;

static const int pcode___menubar__METHOD_Show = pcode___menubar__METHOD_IsVisible + 1;
static const int pcode___menubar__METHOD_Hide = pcode___menubar__METHOD_Show + 1;
static const int pcode___menubar__METHOD_ToggleVisible = pcode___menubar__METHOD_Hide + 1;
static const int pcode___menubar__METHOD_Remove = pcode___menubar__METHOD_ToggleVisible + 1;
static const int pcode___menubar__METHOD_RemoveAll = pcode___menubar__METHOD_Remove + 1;
static const int pcode___menubar__METHOD_RemoveAllChilds = pcode___menubar__METHOD_RemoveAll + 1;
static const int pcode___menubar__METHOD_AppendMenuBarItem = pcode___menubar__METHOD_RemoveAllChilds + 1;
static const int pcode___menubar__METHOD_AppendMenuBarItem1 = pcode___menubar__METHOD_AppendMenuBarItem + 1;
//static const int pcode___menubar__METHOD_AppendSeparator = pcode___menubar__METHOD_Appendmenubar + 1;
static const int pcode___menubar__METHOD_AppendMenu = pcode___menubar__METHOD_AppendMenuBarItem1 + 1;
static const int pcode___menubar__METHOD_AppendMenu1 = pcode___menubar__METHOD_AppendMenu + 1;
static const int pcode___menubar__METHOD_AppendChildMenu = pcode___menubar__METHOD_AppendMenu1 + 1;
static const int pcode___menubar__METHOD_AppendChildMenu1 = pcode___menubar__METHOD_AppendChildMenu + 1;

static const int pcode___menubar__METHOD_AppendContextMenu = pcode___menubar__METHOD_AppendChildMenu1 + 1;
static const int pcode___menubar__METHOD_ShowContextMenu = pcode___menubar__METHOD_AppendContextMenu + 1;
static const int pcode___menubar__METHOD_ShowContextMenu1 = pcode___menubar__METHOD_ShowContextMenu + 1;

static const int pcode___menubar__METHOD_SetWithTag = pcode___menubar__METHOD_ShowContextMenu1 + 1;
static const int pcode___menubar__METHOD_SetWithTag1 = pcode___menubar__METHOD_SetWithTag + 1;
static const int pcode___menubar__METHOD_SetWithTag2 = pcode___menubar__METHOD_SetWithTag1 + 1;

static const int pcode___menubar__METHOD_SetWithGroup = pcode___menubar__METHOD_SetWithTag2 + 1;
static const int pcode___menubar__METHOD_SetWithGroup1 = pcode___menubar__METHOD_SetWithGroup + 1;
static const int pcode___menubar__METHOD_SetWithGroup2 = pcode___menubar__METHOD_SetWithGroup1 + 1;

