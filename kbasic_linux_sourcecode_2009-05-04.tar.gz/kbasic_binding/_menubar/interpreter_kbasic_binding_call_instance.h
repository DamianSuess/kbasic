case pcode___menubar___menubar:{ getParam(v, m, n); pp = new kb_menubar(); myStack->pushParameter(pcode___menubar, pp); ((kb_menubar *) pp)->setInterpreter(this); break; }
case pcode___menubar___menubar1:{ getParam(v, m, n); pp = new kb_menubar(v[0]->to_form()); myStack->pushParameter(pcode___menubar, pp); ((kb_menubar *) pp)->setInterpreter(this); break; }

