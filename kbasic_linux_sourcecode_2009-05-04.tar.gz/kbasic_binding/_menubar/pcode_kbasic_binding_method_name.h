case pcode___menubar___menubar: return "MenuBar";
case pcode___menubar___menubar1: return "MenuBar1";
case pcode___menubar__METHOD_MenuBarItem: return "MenuBarItem";
case pcode___menubar__METHOD_SetVisible: return "SetVisible";
case pcode___menubar__METHOD_IsVisible: return "IsVisible";

case pcode___menubar__METHOD_Show: return "Show";
case pcode___menubar__METHOD_Hide: return "Hide";
case pcode___menubar__METHOD_ToggleVisible: return "ToggleVisible";
case pcode___menubar__METHOD_Remove: return "Remove";
case pcode___menubar__METHOD_RemoveAll: return "RemoveAll";
case pcode___menubar__METHOD_RemoveAllChilds: return "RemoveAllChildren";
case pcode___menubar__METHOD_AppendMenuBarItem: return "AppendMenuBarItem";
case pcode___menubar__METHOD_AppendMenuBarItem1: return "AppendMenuBarItem1";
//case pcode___menubar__METHOD_AppendSeparator: return "AppendSeparator";
case pcode___menubar__METHOD_AppendMenu: return "AppendMenu";
case pcode___menubar__METHOD_AppendMenu1: return "InsertMenu";
case pcode___menubar__METHOD_AppendChildMenu: return "AppendChildMenu";
case pcode___menubar__METHOD_AppendChildMenu1: return "AppendChildMenu1";

case pcode___menubar__METHOD_AppendContextMenu: return "AppendContextMenu";
case pcode___menubar__METHOD_ShowContextMenu: return "ShowContextMenu";
case pcode___menubar__METHOD_ShowContextMenu1: return "ShowContextMenu1";

case pcode___menubar__METHOD_SetWithTag: return "SetWithTag";
case pcode___menubar__METHOD_SetWithTag1: return "SetWithTag1";
case pcode___menubar__METHOD_SetWithTag2: return "SetWithTag2";

case pcode___menubar__METHOD_SetWithGroup: return "SetWithGroup";
case pcode___menubar__METHOD_SetWithGroup1: return "SetWithGroup1";
case pcode___menubar__METHOD_SetWithGroup2: return "SetWithGroup2";
