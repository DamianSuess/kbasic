
new_class(pcode___cmath, 0, 0); 


    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_sin, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_cos, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_tan, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_asin, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_acos, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_atan, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_atan2, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_sinh, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_cosh, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_tanh, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_exp, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_log, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_log10, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_pow, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_sqrt, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_ceil, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_floor, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_fabs, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_ldexp, pcode__DOUBLE);

/*
    new_param("Value", pcode__DOUBLE, false);
    new_param("Value", pcode__POINTER_INTEGER, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_frexp, pcode__DOUBLE);

    new_param("Value", pcode__DOUBLE, false);
    new_param("Value", pcode__POINTER_DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_modf, pcode__DOUBLE);
*/

    new_param("Value", pcode__DOUBLE, false);
    new_param("Value", pcode__DOUBLE, false);
new_staticmethod(true, pcode___cmath, pcode___cmath__METHOD_fmod, pcode__DOUBLE);


