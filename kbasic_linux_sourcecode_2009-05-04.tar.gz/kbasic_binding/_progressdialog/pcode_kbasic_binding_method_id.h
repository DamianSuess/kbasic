static const int pcode___progressdialog___progressdialog = pcode___progressdialog * SPACE;

static const int pcode___progressdialog__METHOD_Show = pcode___progressdialog___progressdialog + 1;
static const int pcode___progressdialog__METHOD_Show1 = pcode___progressdialog__METHOD_Show + 1;
static const int pcode___progressdialog__METHOD_Hide = pcode___progressdialog__METHOD_Show1 + 1;
static const int pcode___progressdialog__METHOD_Canceled = pcode___progressdialog__METHOD_Hide + 1;

static const int pcode___progressdialog__PROPERTYSET_Caption = pcode___progressdialog__METHOD_Canceled + 1;
static const int pcode___progressdialog__PROPERTYGET_Caption = pcode___progressdialog__PROPERTYSET_Caption + 1;

static const int pcode___progressdialog__PROPERTYSET_Text = pcode___progressdialog__PROPERTYGET_Caption + 1;
static const int pcode___progressdialog__PROPERTYGET_Text = pcode___progressdialog__PROPERTYSET_Text + 1;

static const int pcode___progressdialog__PROPERTYSET_CancelCaption = pcode___progressdialog__PROPERTYGET_Text + 1;
static const int pcode___progressdialog__PROPERTYGET_CancelCaption = pcode___progressdialog__PROPERTYSET_CancelCaption + 1;

static const int pcode___progressdialog__PROPERTYSET_Value = pcode___progressdialog__PROPERTYGET_CancelCaption + 1;
static const int pcode___progressdialog__PROPERTYGET_Value = pcode___progressdialog__PROPERTYSET_Value + 1;

static const int pcode___progressdialog__PROPERTYSET_Minimum = pcode___progressdialog__PROPERTYGET_Value + 1;
static const int pcode___progressdialog__PROPERTYGET_Minimum = pcode___progressdialog__PROPERTYSET_Minimum + 1;

static const int pcode___progressdialog__PROPERTYSET_Maximum = pcode___progressdialog__PROPERTYGET_Minimum + 1;
static const int pcode___progressdialog__PROPERTYGET_Maximum = pcode___progressdialog__PROPERTYSET_Maximum + 1;

static const int pcode___progressdialog__PROPERTYSET_Wait = pcode___progressdialog__PROPERTYGET_Maximum + 1;
static const int pcode___progressdialog__PROPERTYGET_Wait = pcode___progressdialog__PROPERTYSET_Wait + 1;
