case pcode___progressdialog___progressdialog: return "ProgressDialog";
  
case pcode___progressdialog__METHOD_Show: return "Show";
case pcode___progressdialog__METHOD_Show1: return "Show1";
case pcode___progressdialog__METHOD_Hide: return "Hide";
case pcode___progressdialog__METHOD_Canceled: return "Canceled";

case pcode___progressdialog__PROPERTYSET_Caption: return "SETPROPERTY_Caption";
case pcode___progressdialog__PROPERTYGET_Caption: return "GETPROPERTY_Caption";

case pcode___progressdialog__PROPERTYSET_Text: return "SETPROPERTY_Text";
case pcode___progressdialog__PROPERTYGET_Text: return "GETPROPERTY_Text";

case pcode___progressdialog__PROPERTYSET_CancelCaption: return "SETPROPERTY_CancelCaption";
case pcode___progressdialog__PROPERTYGET_CancelCaption: return "GETPROPERTY_CancelCaption";

case pcode___progressdialog__PROPERTYSET_Value: return "SETPROPERTY_Value";
case pcode___progressdialog__PROPERTYGET_Value: return "GETPROPERTY_Value";

case pcode___progressdialog__PROPERTYSET_Minimum: return "SETPROPERTY_Minimum";
case pcode___progressdialog__PROPERTYGET_Minimum: return "GETPROPERTY_Minimum";

case pcode___progressdialog__PROPERTYSET_Maximum: return "SETPROPERTY_Maximum";
case pcode___progressdialog__PROPERTYGET_Maximum: return "GETPROPERTY_Maximum";

case pcode___progressdialog__PROPERTYSET_Wait: return "SETPROPERTY_Wait";
case pcode___progressdialog__PROPERTYGET_Wait: return "GETPROPERTY_Wait";
