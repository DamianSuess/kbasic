
new_class(pcode___progressdialog, 0, 0); 

new_staticmethod(true, pcode___progressdialog, pcode___progressdialog__METHOD_Show, pcode__VOID);

	 new_param("Caption", pcode__QString, false);
	 new_param("CancelCaption", pcode__QString, true, "");
new_staticmethod(true, pcode___progressdialog, pcode___progressdialog__METHOD_Show1, pcode__VOID);
new_staticmethod(true, pcode___progressdialog, pcode___progressdialog__METHOD_Hide, pcode__VOID);
new_staticmethod(true, pcode___progressdialog, pcode___progressdialog__METHOD_Canceled, pcode__BOOLEAN);

	 new_param("Caption", pcode__QString, false);
new_staticproperty_set(pcode___progressdialog, pcode___progressdialog__PROPERTYSET_Caption, pcode__VOID);
new_staticproperty_get(pcode___progressdialog, pcode___progressdialog__PROPERTYGET_Caption, pcode__INTEGER);

	 new_param("Text", pcode__QString, false);
new_staticproperty_set(pcode___progressdialog, pcode___progressdialog__PROPERTYSET_Text, pcode__VOID);
new_staticproperty_get(pcode___progressdialog, pcode___progressdialog__PROPERTYGET_Text, pcode__INTEGER);

	 new_param("CancelCaption", pcode__QString, false);
new_staticproperty_set(pcode___progressdialog, pcode___progressdialog__PROPERTYSET_CancelCaption, pcode__VOID);
new_staticproperty_get(pcode___progressdialog, pcode___progressdialog__PROPERTYGET_CancelCaption, pcode__INTEGER);

	 new_param("Value", pcode__INTEGER, false);
new_staticproperty_set(pcode___progressdialog, pcode___progressdialog__PROPERTYSET_Value, pcode__VOID);
new_staticproperty_get(pcode___progressdialog, pcode___progressdialog__PROPERTYGET_Value, pcode__INTEGER);

	 new_param("Minimum", pcode__INTEGER, false);
new_staticproperty_set(pcode___progressdialog, pcode___progressdialog__PROPERTYSET_Minimum, pcode__VOID);
new_staticproperty_get(pcode___progressdialog, pcode___progressdialog__PROPERTYGET_Minimum, pcode__INTEGER);

	 new_param("Maximum", pcode__INTEGER, false);
new_staticproperty_set(pcode___progressdialog, pcode___progressdialog__PROPERTYSET_Maximum, pcode__VOID);
new_staticproperty_get(pcode___progressdialog, pcode___progressdialog__PROPERTYGET_Maximum, pcode__INTEGER);

	 new_param("Wait", pcode__INTEGER, false);
new_staticproperty_set(pcode___progressdialog, pcode___progressdialog__PROPERTYSET_Wait, pcode__VOID);
new_staticproperty_get(pcode___progressdialog, pcode___progressdialog__PROPERTYGET_Wait, pcode__INTEGER);
