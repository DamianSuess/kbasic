
new_class(pcode___toolbaritem, 0, 0); 

	 new_param("f", pcode___form, false);
new_method(true, pcode___toolbaritem, pcode___toolbaritem___toolbaritem, pcode___toolbaritem);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___label, pcode___toolbaritem__SETPROPERTY_ActionId, pcode__VOID);
new_property_get(pcode___label, pcode___toolbaritem__GETPROPERTY_ActionId, pcode__QString);

	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Visible, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Visible, pcode__t_boolean);

	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Checkable, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Checkable, pcode__t_boolean);

	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Checked, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Checked, pcode__t_boolean);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___label, pcode___toolbaritem__SETPROPERTY_ContextMenu, pcode__VOID);
new_property_get(pcode___label, pcode___toolbaritem__GETPROPERTY_ContextMenu, pcode__QString);


	 new_param("n", pcode__QString, false);
new_property_set(pcode___label, pcode___label__SETPROPERTY_StringValue, pcode__VOID);
new_property_get(pcode___label, pcode___label__GETPROPERTY_StringValue, pcode__QString);
new_property_get(pcode___label, pcode___label__GETPROPERTY_OldStringValue, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___label, pcode___label__SETPROPERTY_Caption, pcode__VOID);
new_property_get(pcode___label, pcode___label__GETPROPERTY_Caption, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___label, pcode___label__SETPROPERTY_Text, pcode__VOID);
new_property_get(pcode___label, pcode___label__GETPROPERTY_Text, pcode__QString);


	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_ArrowType, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_ArrowType, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_PopupMode, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_PopupMode, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_ToolBarRole, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_ToolBarRole, pcode__QString);

	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Name, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Name, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_ControlType, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_ControlType, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Tag, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Tag, pcode__QString);
	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Separator, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Separator, pcode__t_boolean);
	 new_param("n", pcode__t_boolean, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Enabled, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Enabled, pcode__t_boolean);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_Icon, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_Icon, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_ToolTip, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_ToolTip, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_StatusTip, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_StatusTip, pcode__QString);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_WhatsThis, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_WhatsThis, pcode__QString);
	 new_param("n", pcode__t_integer, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_ParentIndex, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_ParentIndex, pcode__t_integer);
	 new_param("n", pcode__QString, false);
new_property_set(pcode___toolbaritem, pcode___toolbaritem__SETPROPERTY_SoundOnEvent, pcode__VOID);
new_property_get(pcode___toolbaritem, pcode___toolbaritem__GETPROPERTY_SoundOnEvent, pcode__QString);
new_method(true, pcode___toolbaritem, pcode___toolbaritem__EVENT_OnEvent, pcode__VOID, false, false, false, true);