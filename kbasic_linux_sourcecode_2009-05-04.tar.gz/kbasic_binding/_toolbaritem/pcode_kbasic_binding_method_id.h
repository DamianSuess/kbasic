
static const int pcode___toolbaritem___toolbaritem = pcode___toolbaritem * SPACE;


static const int pcode___toolbaritem__SETPROPERTY_ActionId = pcode___toolbaritem___toolbaritem + 1;
static const int pcode___toolbaritem__GETPROPERTY_ActionId = pcode___toolbaritem__SETPROPERTY_ActionId + 1;

static const int pcode___toolbaritem__SETPROPERTY_Visible = pcode___toolbaritem__GETPROPERTY_ActionId + 1;
static const int pcode___toolbaritem__GETPROPERTY_Visible = pcode___toolbaritem__SETPROPERTY_Visible + 1;

static const int pcode___toolbaritem__SETPROPERTY_Checkable = pcode___toolbaritem__GETPROPERTY_Visible + 1;
static const int pcode___toolbaritem__GETPROPERTY_Checkable = pcode___toolbaritem__SETPROPERTY_Checkable + 1;

static const int pcode___toolbaritem__SETPROPERTY_Checked = pcode___toolbaritem__GETPROPERTY_Checkable + 1;
static const int pcode___toolbaritem__GETPROPERTY_Checked = pcode___toolbaritem__SETPROPERTY_Checked + 1;

static const int pcode___toolbaritem__SETPROPERTY_ContextMenu = pcode___toolbaritem__GETPROPERTY_Checked + 1;
static const int pcode___toolbaritem__GETPROPERTY_ContextMenu = pcode___toolbaritem__SETPROPERTY_ContextMenu + 1;

static const int pcode___toolbaritem__SETPROPERTY_StringValue = pcode___toolbaritem__GETPROPERTY_ContextMenu + 1;
static const int pcode___toolbaritem__GETPROPERTY_StringValue = pcode___toolbaritem__SETPROPERTY_StringValue + 1;

static const int pcode___toolbaritem__GETPROPERTY_OldStringValue = pcode___toolbaritem__GETPROPERTY_StringValue + 1;
static const int pcode___toolbaritem__SETPROPERTY_Caption = pcode___toolbaritem__GETPROPERTY_OldStringValue + 1;
static const int pcode___toolbaritem__GETPROPERTY_Caption = pcode___toolbaritem__SETPROPERTY_Caption + 1;

static const int pcode___toolbaritem__SETPROPERTY_Text = pcode___toolbaritem__GETPROPERTY_Caption + 1;
static const int pcode___toolbaritem__GETPROPERTY_Text = pcode___toolbaritem__SETPROPERTY_Text + 1;

static const int pcode___toolbaritem__SETPROPERTY_ArrowType = pcode___toolbaritem__GETPROPERTY_Text + 1;
static const int pcode___toolbaritem__GETPROPERTY_ArrowType = pcode___toolbaritem__SETPROPERTY_ArrowType + 1;
static const int pcode___toolbaritem__SETPROPERTY_PopupMode = pcode___toolbaritem__GETPROPERTY_ArrowType + 1;
static const int pcode___toolbaritem__GETPROPERTY_PopupMode = pcode___toolbaritem__SETPROPERTY_PopupMode + 1;
static const int pcode___toolbaritem__SETPROPERTY_ToolBarRole = pcode___toolbaritem__GETPROPERTY_PopupMode + 1;
static const int pcode___toolbaritem__GETPROPERTY_ToolBarRole = pcode___toolbaritem__SETPROPERTY_ToolBarRole + 1;

static const int pcode___toolbaritem__SETPROPERTY_Name = pcode___toolbaritem__GETPROPERTY_ToolBarRole + 1;
static const int pcode___toolbaritem__GETPROPERTY_Name = pcode___toolbaritem__SETPROPERTY_Name + 1;
static const int pcode___toolbaritem__SETPROPERTY_ControlType = pcode___toolbaritem__GETPROPERTY_Name + 1;
static const int pcode___toolbaritem__GETPROPERTY_ControlType = pcode___toolbaritem__SETPROPERTY_ControlType + 1;
static const int pcode___toolbaritem__SETPROPERTY_Tag = pcode___toolbaritem__GETPROPERTY_ControlType + 1;
static const int pcode___toolbaritem__GETPROPERTY_Tag = pcode___toolbaritem__SETPROPERTY_Tag + 1;
static const int pcode___toolbaritem__SETPROPERTY_Separator = pcode___toolbaritem__GETPROPERTY_Tag + 1;
static const int pcode___toolbaritem__GETPROPERTY_Separator = pcode___toolbaritem__SETPROPERTY_Separator + 1;
static const int pcode___toolbaritem__SETPROPERTY_Enabled = pcode___toolbaritem__GETPROPERTY_Separator + 1;
static const int pcode___toolbaritem__GETPROPERTY_Enabled = pcode___toolbaritem__SETPROPERTY_Enabled + 1;
static const int pcode___toolbaritem__SETPROPERTY_Icon = pcode___toolbaritem__GETPROPERTY_Enabled + 1;
static const int pcode___toolbaritem__GETPROPERTY_Icon = pcode___toolbaritem__SETPROPERTY_Icon + 1;
static const int pcode___toolbaritem__SETPROPERTY_ToolTip = pcode___toolbaritem__GETPROPERTY_Icon + 1;
static const int pcode___toolbaritem__GETPROPERTY_ToolTip = pcode___toolbaritem__SETPROPERTY_ToolTip + 1;
static const int pcode___toolbaritem__SETPROPERTY_StatusTip = pcode___toolbaritem__GETPROPERTY_ToolTip + 1;
static const int pcode___toolbaritem__GETPROPERTY_StatusTip = pcode___toolbaritem__SETPROPERTY_StatusTip + 1;
static const int pcode___toolbaritem__SETPROPERTY_WhatsThis = pcode___toolbaritem__GETPROPERTY_StatusTip + 1;
static const int pcode___toolbaritem__GETPROPERTY_WhatsThis = pcode___toolbaritem__SETPROPERTY_WhatsThis + 1;
static const int pcode___toolbaritem__SETPROPERTY_ParentIndex = pcode___toolbaritem__GETPROPERTY_WhatsThis + 1;
static const int pcode___toolbaritem__GETPROPERTY_ParentIndex = pcode___toolbaritem__SETPROPERTY_ParentIndex + 1;
static const int pcode___toolbaritem__SETPROPERTY_SoundOnEvent = pcode___toolbaritem__GETPROPERTY_ParentIndex + 1;
static const int pcode___toolbaritem__GETPROPERTY_SoundOnEvent = pcode___toolbaritem__SETPROPERTY_SoundOnEvent + 1;
static const int pcode___toolbaritem__EVENT_OnEvent = pcode___toolbaritem__GETPROPERTY_SoundOnEvent + 1;