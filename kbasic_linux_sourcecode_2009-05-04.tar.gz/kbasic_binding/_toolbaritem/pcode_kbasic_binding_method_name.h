case pcode___toolbaritem___toolbaritem: return "ToolBarItem";

case pcode___toolbaritem__SETPROPERTY_ActionId: return "SETPROPERTY_ActionId";
case pcode___toolbaritem__GETPROPERTY_ActionId: return "GETPROPERTY_ActionId";

case pcode___toolbaritem__SETPROPERTY_Visible: return "SETPROPERTY_Visible";
case pcode___toolbaritem__GETPROPERTY_Visible: return "GETPROPERTY_Visible";

case pcode___toolbaritem__SETPROPERTY_Checkable: return "SETPROPERTY_Checkable";
case pcode___toolbaritem__GETPROPERTY_Checkable: return "GETPROPERTY_Checkable";

case pcode___toolbaritem__SETPROPERTY_Checked: return "SETPROPERTY_Checked";
case pcode___toolbaritem__GETPROPERTY_Checked: return "GETPROPERTY_Checked";

case pcode___toolbaritem__SETPROPERTY_ContextMenu: return "SETPROPERTY_ContextMenu";
case pcode___toolbaritem__GETPROPERTY_ContextMenu: return "GETPROPERTY_ContextMenu";


case pcode___toolbaritem__SETPROPERTY_StringValue: return "SETPROPERTY_StringValue";
case pcode___toolbaritem__GETPROPERTY_StringValue: return "GETPROPERTY_StringValue";
case pcode___toolbaritem__GETPROPERTY_OldStringValue: return "GETPROPERTY_OldStringValue";

case pcode___toolbaritem__SETPROPERTY_Caption: return "SETPROPERTY_Caption";
case pcode___toolbaritem__GETPROPERTY_Caption: return "GETPROPERTY_Caption";

case pcode___toolbaritem__SETPROPERTY_Text: return "SETPROPERTY_Text";
case pcode___toolbaritem__GETPROPERTY_Text: return "GETPROPERTY_Text";

case pcode___toolbaritem__SETPROPERTY_ArrowType: return "SETPROPERTY_ArrowType";
case pcode___toolbaritem__GETPROPERTY_ArrowType: return "GETPROPERTY_ArrowType";

case pcode___toolbaritem__SETPROPERTY_PopupMode: return "SETPROPERTY_PopupMode";
case pcode___toolbaritem__GETPROPERTY_PopupMode: return "GETPROPERTY_PopupMode";

case pcode___toolbaritem__SETPROPERTY_ToolBarRole: return "SETPROPERTY_ToolBarRole";
case pcode___toolbaritem__GETPROPERTY_ToolBarRole: return "GETPROPERTY_ToolBarRole";

case pcode___toolbaritem__SETPROPERTY_Name: return "SETPROPERTY_Name";
case pcode___toolbaritem__GETPROPERTY_Name: return "GETPROPERTY_Name";
case pcode___toolbaritem__SETPROPERTY_ControlType: return "SETPROPERTY_ControlType";
case pcode___toolbaritem__GETPROPERTY_ControlType: return "GETPROPERTY_ControlType";
case pcode___toolbaritem__SETPROPERTY_Tag: return "SETPROPERTY_Tag";
case pcode___toolbaritem__GETPROPERTY_Tag: return "GETPROPERTY_Tag";
case pcode___toolbaritem__SETPROPERTY_Separator: return "SETPROPERTY_Separator";
case pcode___toolbaritem__GETPROPERTY_Separator: return "GETPROPERTY_Separator";
case pcode___toolbaritem__SETPROPERTY_Enabled: return "SETPROPERTY_Enabled";
case pcode___toolbaritem__GETPROPERTY_Enabled: return "GETPROPERTY_Enabled";
case pcode___toolbaritem__SETPROPERTY_Icon: return "SETPROPERTY_Icon";
case pcode___toolbaritem__GETPROPERTY_Icon: return "GETPROPERTY_Icon";
case pcode___toolbaritem__SETPROPERTY_ToolTip: return "SETPROPERTY_ToolTip";
case pcode___toolbaritem__GETPROPERTY_ToolTip: return "GETPROPERTY_ToolTip";
case pcode___toolbaritem__SETPROPERTY_StatusTip: return "SETPROPERTY_StatusTip";
case pcode___toolbaritem__GETPROPERTY_StatusTip: return "GETPROPERTY_StatusTip";
case pcode___toolbaritem__SETPROPERTY_WhatsThis: return "SETPROPERTY_WhatsThis";
case pcode___toolbaritem__GETPROPERTY_WhatsThis: return "GETPROPERTY_WhatsThis";
case pcode___toolbaritem__SETPROPERTY_ParentIndex: return "SETPROPERTY_ParentIndex";
case pcode___toolbaritem__GETPROPERTY_ParentIndex: return "GETPROPERTY_ParentIndex";
case pcode___toolbaritem__EVENT_OnEvent: return "OnEvent";