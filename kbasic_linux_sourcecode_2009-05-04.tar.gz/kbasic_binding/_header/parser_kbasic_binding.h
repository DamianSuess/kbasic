
new_class(pcode___header, pcode___control, 0); 

	 new_param("f", pcode___form, false);
new_method(true, pcode___header, pcode___header___header, pcode___header);