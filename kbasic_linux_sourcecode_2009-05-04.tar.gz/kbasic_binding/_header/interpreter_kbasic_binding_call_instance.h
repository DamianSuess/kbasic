case pcode___header___header:{ getParam(v, m, n); pp = new kb_header(v[0]->to_form()); myStack->pushParameter(pcode___header, pp); ((kb_header *) pp)->setInterpreter(this); break; }
